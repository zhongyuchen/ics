#include "W_stage.h"
#include <iostream>
#include "global_variable.h"
#include "macro.h"
#include "struct.h"

using namespace std;

void write_int(int address, int value)//input theoretical address
{
	memory[address * 2 + 1] = value & 0xf;
	memory[address * 2 + 0] = (value >> 4) & 0xf;
	memory[address * 2 + 3] = (value >> 8) & 0xf;
	memory[address * 2 + 2] = (value >> 12) & 0xf;
	memory[address * 2 + 5] = (value >> 16) & 0xf;
	memory[address * 2 + 4] = (value >> 20) & 0xf;
	memory[address * 2 + 7] = (value >> 24) & 0xf;
	memory[address * 2 + 6] = (value >> 28) & 0xf;
}

void W_value_update()
{
	if (W.bubble)
	{
		W.stat = SBUB;
		W.icode = INOP;
		W.valE = 0;
		W.valM = 0;
		W.dstE = RNONE;
		W.dstM = RNONE;
	}
	else
		if (W.stall)
			;
		else
		{
			W.stat = m.stat;
			W.icode = m.icode;
			W.valE = m.valE;
			W.valM = m.valM;
			W.dstE = m.dstE;
			W.dstM = m.dstM;
		}
}

void W_logic_update()
{
	//Update status of the processor
	if (W.stat == SBUB)
		Stat = SAOK, ins++;
	else
		Stat = W.stat;

	//exit or not?
	switch (Stat)
	{
	case SAOK:
		break;
	case SADR:case SINS:case SHLT:
		error = 1; break;
	}
}

void W_stage()
{
	W_value_update();
	W_logic_update();
}