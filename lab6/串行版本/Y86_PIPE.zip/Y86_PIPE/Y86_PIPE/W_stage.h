#pragma once

void W_value_update();
void W_logic_update();
void W_stage();
void write_int(int address, int value);