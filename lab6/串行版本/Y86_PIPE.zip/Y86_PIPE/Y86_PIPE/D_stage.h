#pragma once

void D_value_update();
void D_logic_update();
void D_stage();