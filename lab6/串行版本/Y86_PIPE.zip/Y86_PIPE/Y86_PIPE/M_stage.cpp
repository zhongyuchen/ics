#include <iostream>
#include "M_stage.h"
#include "macro.h"
#include "struct.h"
#include "global_variable.h"
#include "convert.h"
#include <string>

using namespace std;

bool check_segmentation(int pc)//input real address
{
	if ((pc+4) * 2 < MEMORY_SIZE && pc * 2 >= 0)
		return 0;
	return 1;//segmentation
}

//get an integer from instruction memory
int get_int(int address)//input theoretical address
{
	int ret = 0;
	ret ^= (memory[address * 2 + 1] << 0) & 0xf;
	ret ^= (memory[address * 2 + 0] << 4) & 0xf0;
	ret ^= (memory[address * 2 + 3] << 8) & 0xf00;
	ret ^= (memory[address * 2 + 2] << 12) & 0xf000;
	ret ^= (memory[address * 2 + 5] << 16) & 0xf0000;
	ret ^= (memory[address * 2 + 4] << 20) & 0xf00000;
	ret ^= (memory[address * 2 + 7] << 24) & 0xf000000;
	ret ^= (memory[address * 2 + 6] << 28) & 0xf0000000;
	return ret;
}

void M_value_update()
{
	if (M.bubble)
	{
		M.stat = SBUB;
		M.icode = INOP;
		M.Cnd = 1;//normal
		M.valE = 0;
		M.valA = 0;
		M.dstE = RNONE;
		M.dstM = RNONE;
	}
	else
		if (M.stall)
			;
		else
		{
			M.stat = e.stat;
			M.icode = e.icode;
			M.Cnd = e.Cnd;
			M.valE = e.valE;
			M.valA = e.valA;
			M.dstE = e.dstE;
			M.dstM = e.dstM;
		}
}

void M_logic_update()
{
	char buffer[LENGTH + 10];
	m_do.clear();
	
	//mem.addr
	switch (M.icode)
	{
	case IRMMOVL:case IPUSHL:case ICALL:case IMRMOVL:
		mem.addr = M.valE; break;
	case IPOPL:case IRET:case ILEAVE:
		mem.addr = M.valA; break;
	default:
		break;
	}

	//(either one below can be TRUE)
	//Set read control signal
	mem.read = M.icode == IMRMOVL || M.icode == IPOPL || M.icode == IRET || M.icode == ILEAVE;
	//Set write control signal
	mem.write = M.icode == IRMMOVL || M.icode == IPUSHL || M.icode == ICALL;

	//dmem.error
	if (mem.read||mem.write)
		dmem.error = check_segmentation(mem.addr);
	else
		dmem.error = 0;

	//m.stat
	if (dmem.error)
		m.stat = SADR;
	else
		m.stat = M.stat;

	m.icode = M.icode;
	m.valE = M.valE;
	m.dstE = M.dstE;
	m.dstM = M.dstM;

	//read m.valM in memory with address of mem.addr
	if (!dmem.error&&mem.read)//no data memory error && need to read memory
	{
		m.valM = get_int(mem.addr);
		sprintf(buffer, "valM <- M4[0x%x] = %d", mem.addr, get_int(mem.addr));
		m_do.push_back(buffer);
	}
}

void M_stage()
{
	M_value_update();
	M_logic_update();
}