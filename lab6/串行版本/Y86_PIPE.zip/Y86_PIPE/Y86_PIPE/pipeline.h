#pragma once

#include <iostream>
#include <string>
#include <Windows.h>

using namespace std;

void initialize();
void control_update();
void sequential_update();
void posedge_edge_clock();
void run();