#include "global_variable.h"
#include "struct.h"
#include "macro.h"
#include <vector>
#include <string>
#include <fstream>
#include <Windows.h>
#include <map>
#include "pipeline.h"

using namespace std;

//structures
struct F_register F = F_register();
struct f_value f = f_value();
struct need_value need = need_value();
struct instr_value instr = instr_value();
struct imem_value imem = imem_value();
struct D_register D = D_register();
struct d_value d = d_value();
struct E_register E = E_register();
struct e_value e = e_value();
struct alu_logic alu = alu_logic();
struct CC_register CC = CC_register();
struct M_register M = M_register();
struct dmem_value dmem = dmem_value();
struct mem_value mem = mem_value();
struct m_value m = m_value();
struct W_register W = W_register();

int PC;
//clock cycle
int cycle;
//abnormal exit
bool error;
//Stat: the actual state of the process
int Stat;
int input;
int ins;
double CPI;
int speed;
int output;
int save;

//memory
int memory[MEMORY_SIZE];
//register file
int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
vector<string> seq_do;
vector<string> m_do;
vector<string> e_do;
vector<string> d_do;
vector<string> f_do;
//changed memory
map<int, int> changed;

//file output
ofstream fout;

pthread_t tid[NUM_THREAD];

sem_t control2dmem, control2CC, control2reg;
sem_t control2F_reg, control2D_reg, control2E_reg, control2M_reg, control2W_reg;
sem_t F_reg2F_logic, D_reg2D_logic, E_reg2E_logic, M_reg2M_logic, W_reg2W_logic;
sem_t F_logic2control, D_logic2control, E_logic2control, M_logic2control, W_logic2control;
sem_t M_reg2F_logic, W_reg2F_logic;
sem_t E_logic2D_logic, M_logic2D_logic, W_reg2D_logic;
sem_t dmem2M_reg, CC2E_logic, reg2D_logic;
sem_t D_reg2F_logic, E_reg2D_logic, M_reg2E_logic, W_reg2M_logic;
sem_t reg2W_reg;