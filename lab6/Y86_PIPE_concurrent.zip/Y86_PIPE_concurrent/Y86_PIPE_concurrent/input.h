#pragma once

#include "input.h"

void hex_input();
void binary_input();
void yo_input();