#pragma once

#include "simulator.h"

void simulator();