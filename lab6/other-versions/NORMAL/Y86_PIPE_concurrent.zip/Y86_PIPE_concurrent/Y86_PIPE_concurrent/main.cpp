#include <iostream>
#include "simulator.h"

using namespace std;

int main()
{
	simulator();
}