#include <iostream>
#include <string>
#include "macro.h"
#include "convert.h"
#include "global_variable.h"
#include "struct.h"
#include "output.h"

using namespace std;

//name length: 6
//between name and value: 1
//value length: 11
//between value and next length: 1
void table()
{
	//variables
	int i;
	int p = 0;//pointer
	int need;
	int size;
	const int length = LENGTH - 1;
	string s[OUTPUT_SIZE];
	string temp;
	char buffer[LENGTH + 10];

	//1.cycle line
	need = sprintf(buffer, "CYCLE %d", cycle);
	s[p] = "-----------------------------------------------------------";
	s[p].replace((LENGTH - need) / 2, need, buffer);
	p++;

	//2.parameter section
	s[p++] = "|parameter------------------------------------------------|";

	CPI = (double)cycle / (cycle - ins);
	sprintf(buffer, "|cycle  %11d CPI    %11.8lf ", cycle, CPI);
	s[p] = buffer;

	switch (input)
	{
	case YO: 
		s[p++] += "input     .yo file |"; break;
	case BIN:
		s[p++] += "input  binary file |"; break;
	case HEX:
		s[p++] += "input     hex file |"; break;
	}

	sprintf(buffer, "|speed  %11d ", speed);
	s[p] = buffer;
	if (save == SAV)
		s[p] += "save        enable ";
	else
		s[p] += "save       disable ";
	if (output == STI)
		s[p] += "output       still |";
	else
		s[p] += "output     rolling |";
	p++;

	//3.sequential update section
	s[p++] = "|sequential update----------------------------------------|";

	size = seq_do.size();
	if (size == 0)
	{
		i = 1;
		s[p++] = "|EMPTY                                                    |";
	}
	else
		for (i = 0; i < size; i++)
		{
			s[p] = "|" + seq_do[i];
			s[p].append(length - s[p].size(), ' ');
			s[p++] += "|";
		}

	for (; i < 4; i++)
		s[p++] = "|                                                         |";

	//4.register file section
	s[p++] = "|register file--------------------------------------------|";

	for (i = 0; i < 8; i += 2)
	{
		sprintf(buffer, "%11d ", reg[i]);
		s[p] = "|" + get_reg(i) + "   ";
		s[p] += buffer;

		sprintf(buffer, "%11d ", reg[i + 1]);
		s[p] += get_reg(i + 1) + "   ";
		s[p] += buffer;
		s[p].append(19, ' ');
		s[p++] += "|";
	}

	//5.CC section
	s[p++] = "|CC-------------------------------------------------------|";

	sprintf(buffer, "|ZF     %11d SF     %11d OF     %11d |", CC.ZF, CC.SF, CC.OF);
	s[p++] = buffer;

	//6.stat section
	s[p++] = "|Stat-----------------------------------------------------|";
	s[p++] = "|Stat          " + get_stat(Stat) + "                                       |";

	//7.W register section
	s[p++] = "|W register-----------------------------------------------|";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", W.bubble, W.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(W.stat);
	sprintf(buffer, " valE   %11d valM   %11d |", W.valE, W.valM);
	s[p++] += buffer;

	s[p] = "|icode  ";
	s[p].append(11 - get_icode(W.icode).size(), ' ');
	s[p] += get_icode(W.icode);
	s[p] += " dstE   ";
	s[p].append(11 - get_reg(W.dstE).size(), ' ');
	s[p] += get_reg(W.dstE);
	s[p] += " dstM   ";
	s[p].append(11 - get_reg(W.dstM).size(), ' ');
	s[p++] += get_reg(W.dstM) + " |";

	//8.M register section
	s[p++] = "|M register-----------------------------------------------|";

	if (m_do.size())
	{
		s[p] = "|" + m_do[0];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	else
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", M.bubble, M.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(M.stat);
	sprintf(buffer, " valE   %11d valA   %11d |", M.valE, M.valA);
	s[p++] += buffer;

	s[p] = "|icode  ";
	s[p].append(11 - get_icode(M.icode).size(), ' ');
	s[p] += get_icode(M.icode);
	s[p] += " dstE   ";
	s[p].append(11 - get_reg(M.dstE).size(), ' ');
	s[p] += get_reg(M.dstE);
	s[p] += " dstM   ";
	s[p].append(11 - get_reg(M.dstM).size(), ' ');
	s[p++] += get_reg(M.dstM) + " |";

	sprintf(buffer, "|Cnd    %11d                                       |",M.Cnd);
	s[p++] = buffer;
	
	//9.E register section
	s[p++] = "|E register-----------------------------------------------|";

	if (e_do.size())
	{
		s[p] = "|" + e_do[0];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	else
		s[p++] = "|                                                         |";
	
	sprintf(buffer, "|bubble %11d stall  %11d                    |", E.bubble, E.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(E.stat);
	temp = get_reg(E.dstE);
	s[p] += " dstE   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.dstM);
	s[p] += " dstM   ";
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	temp = get_icode(E.icode);
	s[p] = "|icode  ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	sprintf(buffer, " valA   %11d valB   %11d |", E.valA, E.valB);
	s[p++] += buffer;

	temp = get_ifun(E.icode, E.ifun);
	s[p] = "|ifun   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.srcA);
	s[p] += " srcA   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.srcB);
	s[p] += " srcB   ";
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	sprintf(buffer, "|valC   %11d                                       |", E.valC);
	s[p++] = buffer;
	
	//10.D register section
	s[p++] = "|D register-----------------------------------------------|";
	
	size = d_do.size();
	for (i = 0; i < size; i++)
	{
		s[p] = "|" + d_do[i];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	for (; i < 2; i++)
		s[p++] = "|                                                         |";
	
	sprintf(buffer, "|bubble %11d stall  %11d                    |", D.bubble, D.stall);
	s[p++] = buffer;
	
	s[p] = "|stat          " + get_stat(D.stat);
	sprintf(buffer, " valC   %11d valP   ", D.valC);
	s[p] += buffer;
	s[p].append(13 - sprintf(buffer, "0x%x |", D.valP), ' ');
	s[p++] += buffer;

	s[p] = "|icode  ";
	temp = get_icode(D.icode);
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	s[p] += " rA     ";
	temp = get_reg(D.rA);
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	s[p] += " rB     ";
	temp = get_reg(D.rB);
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	s[p] = "|ifun   ";
	temp = get_ifun(D.icode, D.ifun);
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + "                                       |";

	//11.F register section
	s[p++] = "|F register-----------------------------------------------|";
	
	size = f_do.size();
	for (i = 0; i < size; i++)
	{
		s[p] = "|" + f_do[i];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	for (; i < 5; i++)
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", F.bubble, F.stall);
	s[p++] = buffer;

	s[p] = "|f.pc   ";
	s[p].append(11 - sprintf(buffer, "0x%x", f.pc), ' ');
	s[p] += buffer;
	s[p] += " predPC ";
	s[p].append(11 - sprintf(buffer, "0x%x", F.predPC), ' ');
	s[p] += buffer;
	s[p++] += "                    |";

	//12.changed memory section
	s[p++] = "|changed memory-------------------------------------------|";

	if (changed.empty())
		s[p++] = "|EMPTY                                                    |";
	else
	{
		s[p++] = "|     address      |     decimal      |    hexadecimal    |";
		for (map<int, int>::const_iterator it = changed.begin(); it != changed.end(); it++)
		{
			s[p] = "|";
			s[p].append(18 - sprintf(buffer, "0x%x", it->first), ' ');
			s[p] += buffer;
			s[p] += "|";
			s[p].append(18 - sprintf(buffer, "%d", it->second), ' ');
			s[p] += buffer;
			s[p] += "|";
			s[p].append(18 - sprintf(buffer, "0x%x", it->second), ' ');
			s[p] += buffer;
			s[p++] += " |";
		}
	}

	//13.bottom line
	s[p++] = "-----------------------------------------------------------";

	//save as file?
	if (save == SAV)
	{
		for (i = 0; i < p; i++)
			fout << s[i] << endl;
		fout << endl << endl << endl;
	}

	//output
	if (output == STI)//double buffer display
	{
		COORD coord;//˫���崦����ʾ
		DWORD bytes;//����̨��Ļ���������
		HANDLE hOutput = CreateConsoleScreenBuffer(
			GENERIC_WRITE,//������̿�����������д����
			FILE_SHARE_WRITE,//���建�����ɹ���дȨ��
			NULL,
			CONSOLE_TEXTMODE_BUFFER,
			NULL
		);

		coord.X = 0;
		coord.Y = 0;
		bytes = 0;
		for (i = 0; i < p; i++)
		{
			coord.Y = i;
			WriteConsoleOutputCharacterA(hOutput, s[i].c_str(), s[i].size(), coord, &bytes);
		}
		SetConsoleActiveScreenBuffer(hOutput);
	}
	else//rolling display
	{
		for (i = 0; i < p; i++)
			cout << s[i] << endl;
		cout << endl << endl << endl;
	}
}