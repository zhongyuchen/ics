#include <iostream>
#include "global_variable.h"
#include "macro.h"
#include "struct.h"
#include "convert.h"
#include "F_stage.h"
#include "M_stage.h"

using namespace std;

void *F_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2F_reg);

		printf("---F_reg\n");

		if (F.bubble)
			;//F stage can't be bubbled anyway
		else
			if (F.stall)//no change
				;
			else
				F.predPC = f.predPC;
		V(&F_reg2F_logic);
	}

	return NULL;
}

void *F_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		P(&F_reg2F_logic);
		P(&D_reg2F_logic);
		P(&M_reg2F_logic);
		P(&W_reg2F_logic);
		
		printf("---F_logic\n");
		
		f_do.clear();

		//f.pc: What address should instruction be fetched at
		if (M.icode == IJXX && M.Cnd == 0)//predict error!
		{
			f.pc = M.valA;
			sprintf(buffer, "f.pc <- M.valA = 0x%x", M.valA);
			f_do.push_back(buffer);
		}
		else
			if (W.icode == IRET)
			{
				f.pc = W.valM;
				sprintf(buffer, "f.pc <- W.valM = 0x%x", W.valM);
				f_do.push_back(buffer);
			}
			else
			{
				f.pc = F.predPC;
				sprintf(buffer, "f.pc <- F.predPC = 0x%x", F.predPC);
				f_do.push_back(buffer);
			}

		//use PC to read memory for instruction codes
		imem.error = check_segmentation(f.pc + 12);
		if (!imem.error)
		{
			imem.icode = memory[f.pc * 2];
			imem.ifun = memory[f.pc * 2 + 1];
		}

		//f.icode: Determine icode of fetched instruction
		//f.ifun: determin ifun
		if (imem.error)
			f.icode = INOP, f.ifun = FNONE;
		else
			f.icode = imem.icode, f.ifun = imem.ifun;

		//fetch icode & ifun
		sprintf(buffer, "icode:ifun <- M1[0x%x] = %x:%x = ", f.pc, f.icode, f.ifun);
		f_do.push_back(buffer + get_icode(f.icode) + ":" + get_ifun(f.icode, f.ifun));

		//Is instruction valid?
		instr.valid =
			f.icode == INOP && f.ifun == FNONE ||
			f.icode == IHALT && f.ifun == FNONE ||
			f.icode == IRRMOVL && f.ifun >= FJMP && f.ifun <= FJG ||
			f.icode == IIRMOVL && f.ifun == FNONE ||
			f.icode == IRMMOVL && f.ifun == FNONE ||
			f.icode == IMRMOVL && f.ifun == FNONE ||
			f.icode == IOPL && f.ifun <= FXORL && f.ifun >= FADDL ||
			f.icode == IJXX && f.ifun <= FJG && f.ifun >= FJMP ||
			f.icode == ICALL && f.ifun == FNONE ||
			f.icode == IRET && f.ifun == FNONE ||
			f.icode == IPUSHL && f.ifun == FNONE ||
			f.icode == IPOPL && f.ifun == FNONE ||
			f.icode == IIADDL && f.ifun == FNONE ||
			f.icode == ILEAVE && f.ifun == FNONE;

		//Determine status code for fetched instruction
		if (imem.error)
			f.stat = SADR;
		else
			if (!instr.valid)
				f.stat = SINS;
			else
				if (f.icode == IHALT)
					f.stat = SHLT;
				else
					f.stat = SAOK;//normal

		//Does fetched instruction require a reg-id byte?
		need.regids =
			f.icode == IRRMOVL ||
			f.icode == IOPL ||
			f.icode == IPUSHL ||
			f.icode == IPOPL ||
			f.icode == IIRMOVL ||
			f.icode == IRMMOVL ||
			f.icode == IMRMOVL ||
			f.icode == IIADDL;

		if (need.regids)
		{
			f.rA = memory[f.pc * 2 + 2];
			f.rB = memory[f.pc * 2 + 3];
			sprintf(buffer, "rA:rB <- M1[0x%x] = %x:%x = ", f.pc + 1, f.rA, f.rB);
			f_do.push_back(buffer + get_reg(f.rA) + ":" + get_reg(f.rB));
		}
		else
		{
			f.rA = f.rB = RNONE;
			f_do.push_back("rA:rB <- f:f = ENONE:ENONE");
		}

		//Does fetched instruction require a constant word?
		need.valC =
			f.icode == IIRMOVL ||
			f.icode == IRMMOVL ||
			f.icode == IMRMOVL ||
			f.icode == IJXX ||
			f.icode == ICALL ||
			f.icode == IIADDL;

		if (need.valC)
			if (need.regids)
			{
				f.valC = get_int(f.pc + 2);
				sprintf(buffer, "valC <- M4[0x%x] = %d", f.pc + 2, f.valC);
				f_do.push_back(buffer);
			}
			else
			{
				f.valC = get_int(f.pc + 1);
				sprintf(buffer, "valC <- M4[0x%x] = %d", f.pc + 1, f.valC);
				f_do.push_back(buffer);
			}

		//f.valP
		f.valP = f.pc + 1 + need.regids * 1 + need.valC * 4;
		sprintf(buffer, "valP <- 0x%x + %d = 0x%x", f.pc, 1 + need.regids * 1 + need.valC * 4, f.valP);
		f_do.push_back(buffer);

		//Predict next value of PC
		if (f.icode == IJXX || f.icode == ICALL)
			f.predPC = f.valC;
		else
			f.predPC = f.valP;

		V(&F_logic2control);
	}

	return NULL;
}

//void F_stage()
//{
//	F_value_update();
//	F_logic_update();
//}