#pragma once

#include <iostream>
#include <string>
#include <Windows.h>
#include <pthread.h>
//#include <thread>
#include <semaphore.h>
//#include <mutex>

#pragma comment(lib,"pthreadVC2.lib")

using namespace std;

void initialize();
void control_update();
void *dmem_update(void *vargp);
void *CC_update(void *vargp);
void *reg_update(void *vargp);
void sequential_update();
void posedge_edge_clock();
void run();

void concurrent_run();

void I(sem_t *sem, unsigned int value);
void P(sem_t *sem);
void V(sem_t *sem);