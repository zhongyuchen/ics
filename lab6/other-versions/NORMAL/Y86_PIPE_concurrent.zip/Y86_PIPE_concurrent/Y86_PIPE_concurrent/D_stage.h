#pragma once

void *D_value_update(void *vargp);
void *D_logic_update(void *vargp);
//void D_stage();