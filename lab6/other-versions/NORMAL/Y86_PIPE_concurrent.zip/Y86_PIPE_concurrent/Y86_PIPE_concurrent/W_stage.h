#pragma once

void *W_value_update(void *vargp);
void *W_logic_update(void *vargp);
//void W_stage();
void write_int(int address, int value);