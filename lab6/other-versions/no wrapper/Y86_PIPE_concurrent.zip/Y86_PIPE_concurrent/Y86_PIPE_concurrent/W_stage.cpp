#include "W_stage.h"
#include <iostream>
#include "global_variable.h"
#include "macro.h"
#include "struct.h"

using namespace std;

void write_int(int address, int value)//input theoretical address
{
	memory[address * 2 + 1] = value & 0xf;
	memory[address * 2 + 0] = (value >> 4) & 0xf;
	memory[address * 2 + 3] = (value >> 8) & 0xf;
	memory[address * 2 + 2] = (value >> 12) & 0xf;
	memory[address * 2 + 5] = (value >> 16) & 0xf;
	memory[address * 2 + 4] = (value >> 20) & 0xf;
	memory[address * 2 + 7] = (value >> 24) & 0xf;
	memory[address * 2 + 6] = (value >> 28) & 0xf;
}

void *W_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		sem_wait(&control2W_reg);
		sem_wait(&reg2W_reg);

		//printf("---W_reg\n");
		if (W.bubble)
		{
			W.stat = SBUB;
			W.icode = INOP;
			W.valE = 0;
			W.valM = 0;
			W.dstE = RNONE;
			W.dstM = RNONE;
		}
		else
			if (W.stall)
				;
			else
			{
				W.stat = m.stat;
				W.icode = m.icode;
				W.valE = m.valE;
				W.valM = m.valM;
				W.dstE = m.dstE;
				W.dstM = m.dstM;
			}
		sem_post(&W_reg2F_logic);
		sem_post(&W_reg2D_logic);
		//sem_post(&W_reg2E_logic);//new
		sem_post(&W_reg2M_logic);
		sem_post(&W_reg2W_logic);
	}

	return NULL;
}

void *W_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		sem_wait(&W_reg2W_logic);
		//printf("---W_logic\n");
		//Update status of the processor
		if (W.stat == SBUB)
			Stat = SAOK, ins++;
		else
			Stat = W.stat;

		//exit or not?
		switch (Stat)
		{
		case SAOK:
			break;
		case SADR:case SINS:case SHLT:
			error = 1; break;
		}

		sem_post(&W_logic2control);
	}

	return NULL;
}

//void W_stage()
//{
//	W_value_update();
//	W_logic_update();
//}