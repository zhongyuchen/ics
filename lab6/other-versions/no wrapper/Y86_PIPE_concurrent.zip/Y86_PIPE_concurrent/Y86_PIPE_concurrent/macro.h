#pragma once

//icode(instruction code)
#define IHALT 0x0
#define INOP 0x1
#define IRRMOVL 0x2
#define IIRMOVL 0x3
#define IRMMOVL 0x4
#define IMRMOVL 0x5
#define IOPL 0x6
#define IJXX 0x7
#define ICALL 0x8
#define IRET 0x9
#define IPUSHL 0xa
#define IPOPL 0xb
#define IIADDL 0xc
#define ILEAVE 0xd

//ifun(instruction function code)
//1.icode default
#define FNONE 0x0
//2.icode IOPL
#define FADDL 0x0//ALU add operation
#define ALUADD 0x0//(for icode except IOPL) ALU add operation
#define FSUBL 0x1
#define FANDL 0x2
#define FXORL 0x3
//3.icode IJXX
#define FJMP 0x0
#define FJLE 0x1
#define FJL 0x2
#define FJE 0x3
#define FJNE 0x4
#define FJGE 0x5
#define FJG 0x6

//register function
#define EAX 0x0
#define ECX 0x1
#define EDX 0x2
#define EBX 0x3
#define ESP 0x4
#define EBP 0x5
#define ESI 0x6
#define EDI 0x7
#define E8 0x8
#define E9 0x9
#define E10 0xa
#define E11 0xb
#define E12 0xc
#define E13 0xd
#define E14 0xe
#define ENONE 0xf//not exist
//common register
#define RRSP 0x4//%esp
#define RNONE 0xf//no register

//instruction status values
#define SBUB 0x0//bubble
#define SAOK 0x1//normal
#define SADR 0x2//address abnormal
#define SINS 0x3//instruction abnormal
#define SHLT 0x4//halt

//memory size
#define MEMORY_SIZE 0x10000000

//output table size
#define OUTPUT_SIZE 300
#define LENGTH 59

//file category
#define YO 0
#define BIN 1
#define HEX 2

//display category
#define ROL 0
#define STI 1

//save file?
#define SAV 1
#define SEE 0

//colours
#define WHITE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE)
#define GREEN SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_GREEN)
#define BLUE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_BLUE)
#define RED SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED)
#define YELLOW SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN)
#define MAGENTA SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE)
#define CYAN SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_BLUE)

#define NUM_THREAD 13