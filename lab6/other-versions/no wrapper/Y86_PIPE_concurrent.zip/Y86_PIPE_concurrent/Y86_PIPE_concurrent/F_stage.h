#pragma once

void *F_value_update(void *vargp);
void *F_logic_update(void *vargp);
//void F_stage();