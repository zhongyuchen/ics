#pragma once

struct F_register
{
	int predPC;
	bool bubble;
	bool stall;
};

struct f_value
{
	int icode;
	int ifun;
	int valC;
	int valP;
	int pc;
	int stat;
	int predPC;
	int rA;
	int rB;
};

struct need_value
{
	int valC;
	int regids;
};

struct instr_value
{
	bool valid;
};

struct imem_value
{
	int icode;
	int ifun;
	bool error;
};

struct D_register
{
	int stat;
	int icode;
	int ifun;
	int rA;
	int rB;
	int valC;
	int valP;
	bool bubble;
	bool stall;
};

struct d_value
{
	int srcA;
	int srcB;
	int dstE;
	int dstM;
	int valA;
	int valB;
	int rvalA;
	int rvalB;
	int stat;
	int icode;
	int ifun;
	int valC;
};

struct E_register
{
	int stat;
	int icode;
	int ifun;
	int valC;
	int valA;
	int valB;
	int dstE;
	int dstM;
	int srcA;
	int srcB;
	bool bubble;
	bool stall;
};

struct e_value
{
	int valE;
	int dstE;
	int dstM;
	int valA;
	int stat;
	int icode;
	bool Cnd;
};

struct alu_logic
{
	int A;
	int B;
	int fun;
	bool ZF;
	bool SF;
	bool OF;
};

struct CC_register
{
	bool ZF;//zero flag
	bool SF;//sign flag
	bool OF;//overflow flag
	bool set;
};

struct M_register
{
	int stat;
	int icode;
	int ifun;
	int Cnd;
	int valE;
	int valA;
	int dstE;
	int dstM;
	bool bubble;
	bool stall;
};

struct dmem_value
{
	bool error;
};

struct mem_value
{
	int addr;
	bool read;
	bool write;
};

struct m_value
{
	int valM;
	int stat;
	int icode;
	int valE;
	int dstE;
	int dstM;
};

struct W_register
{
	int stat;
	int icode;
	int valE;
	int valM;
	int dstE;
	int dstM;
	bool stall;
	bool bubble;
};