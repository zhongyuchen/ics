#include <iostream>
#include "struct.h"
#include "global_variable.h"
#include "E_stage.h"
#include "convert.h"

using namespace std;

void ALU()
{
	char buffer[LENGTH + 10];
	e_do.clear();
	
	//input: alu_A, alu_B, alu_fun
	//update: CC, valE
	switch (alu_fun)
	{
	case FADDL:
		e_valE = alu_B + alu_A;
		alu_OF = (alu_B < 0 == alu_A < 0) && (e_valE < 0 != alu_B < 0);
		sprintf(buffer, "valE <- %d + %d = %d", alu_B, alu_A, e_valE);
		e_do.push_back(buffer);
		break;
	case FSUBL:
		e_valE = alu_B - alu_A;
		alu_OF = (alu_B < 0 == (-alu_A) < 0) && (e_valE < 0 != alu_B < 0);
		sprintf(buffer, "valE <- %d - %d = %d", alu_B, alu_A, e_valE);
		e_do.push_back(buffer);
		break;
	case FANDL:
		e_valE = alu_B & alu_A;
		alu_OF = 0;
		sprintf(buffer, "valE <- %d & %d = %d", alu_B, alu_A, e_valE);
		e_do.push_back(buffer);
		break;
	case FXORL:
		e_valE = alu_B ^ alu_A;
		alu_OF = 0;
		sprintf(buffer, "valE <- %d ^ %d = %d", alu_B, alu_A, e_valE);
		e_do.push_back(buffer);	
		break;
	default:
		break;
	}
	alu_SF = e_valE < 0;
	alu_ZF = e_valE == 0;
}

void *E_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2E_reg);
		//printf("---E_reg\n");
		if (E_bubble)
		{
			E_stat = SBUB;
			E_icode = INOP;
			E_ifun = FNONE;
			E_valC = 0;
			E_valA = 0;
			E_valB = 0;
			E_dstE = RNONE;
			E_dstM = RNONE;
			E_srcA = RNONE;
			E_srcB = RNONE;
		}
		else
			if (E_stall)
				;
			else
			{
				E_stat = d_stat;
				E_icode = d_icode;
				E_ifun = d_ifun;
				E_valC = d_valC;
				E_valA = d_valA;
				E_valB = d_valB;
				E_dstE = d_dstE;
				E_dstM = d_dstM;
				E_srcA = d_srcA;
				E_srcB = d_srcB;
			}
		V(&E_reg2E_logic);
		V(&E_reg2D_logic);
	}

	return NULL;
}

void *E_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&E_reg2E_logic);
		P(&M_reg2E_logic);
		P(&CC2E_logic);

		//printf("---E_logic\n");
		e_stat = E_stat;
		e_icode = E_icode;
		e_dstM = E_dstM;
		e_valA = E_valA;

		//alu_A
		switch (E_icode)
		{
		case IRRMOVL:case IOPL:
			alu_A = E_valA; break;
		case IIRMOVL:case IRMMOVL:case IMRMOVL:case IIADDL:
			alu_A = E_valC; break;
		case ICALL:case IPUSHL:
			alu_A = -4; break;
		case IRET:case IPOPL:case ILEAVE:
			alu_A = 4; break;
		default:
			alu_A = 0; break;
		}

		//alu_B
		switch (E_icode)
		{
		case IMRMOVL:case IRMMOVL:case IOPL:case ICALL:case IPUSHL:case IRET:case IPOPL:case IIADDL:case ILEAVE:
			alu_B = E_valB; break;
		case IRRMOVL:case IIRMOVL:
			alu_B = 0; break;
		default:
			alu_B = 0; break;
		}

		//alu_fun
		switch (E_icode)
		{
		case IOPL:
			alu_fun = E_ifun; break;
		default:
			alu_fun = ALUADD; break;
		}

		//ALU operation
		ALU();

		//input: CC(ZF,SF,OF), E_ifun
		//output: e_Cnd(if predict error, set it 0)
		switch (E_ifun)
		{
		case FJMP:
			e_Cnd = 1; break;
		case FJLE:
			e_Cnd = (CC_SF^CC_OF) | CC_ZF; break;
		case FJL:
			e_Cnd = CC_SF^CC_OF; break;
		case FJE:
			e_Cnd = CC_ZF; break;
		case FJNE:
			e_Cnd = !CC_ZF; break;
		case FJGE:
			e_Cnd = !(CC_SF^CC_OF); break;
		case FJG:
			e_Cnd = !(CC_SF^CC_OF)&(!CC_ZF); break;
		default:
			e_Cnd = 1; break;//normal, e_Cnd should be 1
		}

		//Set dstE to RNONE in event of not-taken conditional move
		if (E_icode == IRRMOVL && !e_Cnd)
			e_dstE = RNONE;
		else
			e_dstE = E_dstE;

		//Should the condition codes be updated?
		//Set CC: a sequential update, update CC at the end of the stage
		CC_set =
			(E_icode == IOPL || E_icode == IIADDL) &&
			(m_stat != SADR && m_stat != SINS && m_stat != SHLT) &&
			(W_stat != SADR && W_stat != SINS && W_stat != SHLT);
		
		V(&E_logic2D_logic);
		V(&E_logic2control);
	}

	return NULL;
}

//void E_stage()
//{
//	E_value_update();
//	E_logic_update();
//}