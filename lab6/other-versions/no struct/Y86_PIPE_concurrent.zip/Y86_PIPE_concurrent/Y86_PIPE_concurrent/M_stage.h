#pragma once

bool check_segmentation(int pc);//input real address
void *M_value_update(void *vargp);
void *M_logic_update(void *vargp);
//void M_stage();
int get_int(int address);