#include "D_stage.h"
#include <iostream>
#include "macro.h"
#include "global_variable.h"
#include "struct.h"
#include "convert.h"

using namespace std;

void *D_value_update(void *vargp)//the data from F goes in D register
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2D_reg);
		//printf("---D_reg\n");
		if (D_bubble)
		{
			D_stat = SBUB;
			D_icode = INOP;
			D_ifun = FNONE;
			D_rA = RNONE;
			D_rB = RNONE;
			D_valC = 0;
			D_valP = 0;
		}
		else
			if (D_stall)//stall: keep the value not changed
				;
			else//pass on the values from f
			{
				D_stat = f_stat;
				D_icode = f_icode;
				D_ifun = f_ifun;
				D_rA = f_rA;
				D_rB = f_rB;
				D_valC = f_valC;
				D_valP = f_valP;
			}
		V(&D_reg2D_logic);
		V(&D_reg2F_logic);
	}

	return NULL;
}

void *D_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		P(&reg2D_logic);
		P(&D_reg2D_logic);
		P(&E_reg2D_logic);
		P(&E_logic2D_logic);
		P(&M_logic2D_logic);
		P(&W_reg2D_logic);

		//printf("---D_logic\n");
		d_do.clear();

		d_stat = D_stat;
		d_icode = D_icode;
		d_ifun = D_ifun;
		d_valC = D_valC;

		//d_srcA
		switch (D_icode)
		{
		case IRRMOVL:case IRMMOVL:case IOPL:case IPUSHL:case IIADDL:
			d_srcA = D_rA; break;
		case IPOPL:case IRET:
			d_srcA = RRSP; break;
		case ILEAVE:
			d_srcA = EBP; break;
		default:
			d_srcA = RNONE; break;
		}

		//d_srcB
		switch (D_icode)
		{
		case IOPL:case IRMMOVL:case IMRMOVL:case IIADDL:
			d_srcB = D_rB; break;
		case IPUSHL:case IPOPL:case ICALL:case IRET:
			d_srcB = RRSP; break;
		case ILEAVE:
			d_srcB = EBP; break;
		default:
			d_srcB = RNONE; break;
		}

		//d_dstE
		switch (D_icode)
		{
		case IRRMOVL:case IIRMOVL:case IOPL:case IIADDL:
			d_dstE = D_rB; break;
		case IPUSHL:case IPOPL:case ICALL:case IRET:case ILEAVE:
			d_dstE = RRSP; break;
		default:
			d_dstE = RNONE; break;
		}

		//d_dstM
		switch (D_icode)
		{
		case IMRMOVL:case IPOPL:
			d_dstM = D_rA; break;
		case ILEAVE:
			d_dstM = EBP; break;
		default:
			d_dstM = RNONE; break;
		}

		//d_rvalA, d_rvalB
		d_rvalA = reg[d_srcA];
		d_rvalB = reg[d_srcB];

		//d_valA (Forward into decode stage for valA)
		if (D_icode == ICALL || D_icode == IJXX)//Use incremented PC
		{
			d_valA = D_valP;
			sprintf(buffer, "valA <- D_valP = %d", D_valP);
			d_do.push_back(buffer);
		}
		else
			if (d_srcA == e_dstE)//forward valE from execute
			{
				d_valA = e_valE;
				sprintf(buffer, "valA <- e_valE = %d", e_valE);
				d_do.push_back(buffer);
			}
			else
				if (d_srcA == M_dstM)//forward valM from memory
				{
					d_valA = m_valM;
					sprintf(buffer, "valA <- m_valM = %d", m_valM);
					d_do.push_back(buffer);
				}
				else
					if (d_srcA == M_dstE)//Forward valE from memory
					{
						d_valA = M_valE;
						sprintf(buffer, "valA <- M_valE = %d", M_valE);
						d_do.push_back(buffer);
					}
					else
						if (d_srcA == W_dstM)//Forward valM from write back
						{
							d_valA = W_valM;
							sprintf(buffer, "valA <- W_valM = %d", W_valM);
							d_do.push_back(buffer);
						}
						else
							if (d_srcA == W_dstE)//Forward valE from write back
							{
								d_valA = W_valE;
								sprintf(buffer, "valA <- W_valE = %d", W_valE);
								d_do.push_back(buffer);
							}
							else//Use value read from register file
							{
								d_valA = d_rvalA;
								sprintf(buffer, "%d", reg[d_srcA]);
								d_do.push_back("valA <- R[" + get_reg(d_srcA) + "] = " + buffer);
							}

		//d_valB
		if (d_srcB == e_dstE)//Forward valE from execute
		{
			d_valB = e_valE;
			sprintf(buffer, "valB <- e_valE = %d", e_valE);
			d_do.push_back(buffer);
		}
		else
			if (d_srcB == M_dstM)//Forward valM from memory
			{
				d_valB = m_valM;
				sprintf(buffer, "valB <- m_valM = %d", m_valM);
				d_do.push_back(buffer);
			}
			else
				if (d_srcB == M_dstE)//Forward valE from memory
				{
					d_valB = M_valE;
					sprintf(buffer, "valB <- M_valE = %d", M_valE);
					d_do.push_back(buffer);
				}
				else
					if (d_srcB == W_dstM)//Forward valM from write back
					{
						d_valB = W_valM;
						sprintf(buffer, "valB <- W_valM = %d", W_valM);
						d_do.push_back(buffer);
					}
					else
						if (d_srcB == W_dstE)//Forward valE from write back
						{
							d_valB = W_valE;
							sprintf(buffer, "valB <- W_valE = %d", W_valE);
							d_do.push_back(buffer);
						}
						else//Use value read from register file
						{
							d_valB = d_rvalB;
							sprintf(buffer, "%d", reg[d_srcB]);
							d_do.push_back("valB <- R[" + get_reg(d_srcB) + "] = " + buffer);
						}

		V(&D_logic2control);
	}

	return NULL;
}

//void D_stage()
//{
//	D_value_update();
//	D_logic_update();
//}