#pragma once

void ALU();
void *E_value_update(void *vargp);
void *E_logic_update(void *vargp);
//void E_stage();