#include "global_variable.h"
#include "struct.h"
#include "macro.h"
#include <vector>
#include <string>
#include <fstream>
#include <Windows.h>
#include <map>
#include "pipeline.h"

using namespace std;

int F_predPC;
bool F_bubble;
bool F_stall;

int f_icode;
int f_ifun;
int f_valC;
int f_valP;
int f_pc;
int f_stat;
int f_predPC;
int f_rA;
int f_rB;

int need_valC;
int need_regids;

bool instr_valid;

int imem_icode;
int imem_ifun;
bool imem_error;

int D_stat;
int D_icode;
int D_ifun;
int D_rA;
int D_rB;
int D_valC;
int D_valP;
bool D_bubble;
bool D_stall;

int d_srcA;
int d_srcB;
int d_dstE;
int d_dstM;
int d_valA;
int d_valB;
int d_rvalA;
int d_rvalB;
int d_stat;
int d_icode;
int d_ifun;
int d_valC;

int E_stat;
int E_icode;
int E_ifun;
int E_valC;
int E_valA;
int E_valB;
int E_dstE;
int E_dstM;
int E_srcA;
int E_srcB;
bool E_bubble;
bool E_stall;

int e_valE;
int e_dstE;
int e_dstM;
int e_valA;
int e_stat;
int e_icode;
bool e_Cnd;

int alu_A;
int alu_B;
int alu_fun;
bool alu_ZF;
bool alu_SF;
bool alu_OF;

bool CC_ZF;//zero flag
bool CC_SF;//sign flag
bool CC_OF;//overflow flag
bool CC_set;

int M_stat;
int M_icode;
int M_ifun;
int M_Cnd;
int M_valE;
int M_valA;
int M_dstE;
int M_dstM;
bool M_bubble;
bool M_stall;

bool dmem_error;

int mem_addr;
bool mem_read;
bool mem_write;

int m_valM;
int m_stat;
int m_icode;
int m_valE;
int m_dstE;
int m_dstM;

int W_stat;
int W_icode;
int W_valE;
int W_valM;
int W_dstE;
int W_dstM;
bool W_stall;
bool W_bubble;

int PC;
//clock cycle
int cycle;
//abnormal exit
bool error;
//Stat: the actual state of the process
int Stat;
int input;
int ins;
double CPI;
int speed;
int output;
int save;

//memory
int memory[MEMORY_SIZE];
//register file
int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
vector<string> seq_do;
vector<string> m_do;
vector<string> e_do;
vector<string> d_do;
vector<string> f_do;
//changed memory
map<int, int> changed;

//file output
ofstream fout;

pthread_t tid[NUM_THREAD];

sem_t control2dmem, control2CC, control2reg;
sem_t control2F_reg, control2D_reg, control2E_reg, control2M_reg, control2W_reg;
sem_t F_reg2F_logic, D_reg2D_logic, E_reg2E_logic, M_reg2M_logic, W_reg2W_logic;

sem_t F_logic2control, D_logic2control, E_logic2control, M_logic2control, W_logic2control;

sem_t M_reg2F_logic, W_reg2F_logic;
sem_t E_logic2D_logic, M_logic2D_logic, W_reg2D_logic;

sem_t dmem2M_reg, CC2E_logic, reg2D_logic;

sem_t D_reg2F_logic, E_reg2D_logic, M_reg2E_logic, W_reg2M_logic;

sem_t reg2W_reg;