#include <iostream>
#include "global_variable.h"
#include "macro.h"
#include "struct.h"
#include "convert.h"
#include "F_stage.h"
#include "M_stage.h"

using namespace std;

void *F_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2F_reg);

		//printf("---F_reg\n");
		if (F_bubble)
			;//F stage can't be bubbled anyway
		else
			if (F_stall)//no change
				;
			else
				F_predPC = f_predPC;
		V(&F_reg2F_logic);
	}

	return NULL;
}

void *F_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		P(&F_reg2F_logic);
		P(&D_reg2F_logic);
		P(&M_reg2F_logic);
		P(&W_reg2F_logic);
		//printf("---F_logic\n");
		f_do.clear();

		//f_pc: What address should instruction be fetched at
		if (M_icode == IJXX && M_Cnd == 0)//predict error!
		{
			f_pc = M_valA;
			sprintf(buffer, "f_pc <- M_valA = 0x%x", M_valA);
			f_do.push_back(buffer);
		}
		else
			if (W_icode == IRET)
			{
				f_pc = W_valM;
				sprintf(buffer, "f_pc <- W_valM = 0x%x", W_valM);
				f_do.push_back(buffer);
			}
			else
			{
				f_pc = F_predPC;
				sprintf(buffer, "f_pc <- F_predPC = 0x%x", F_predPC);
				f_do.push_back(buffer);
			}

		//use PC to read memory for instruction codes
		imem_error = check_segmentation(f_pc + 12);
		if (!imem_error)
		{
			imem_icode = memory[f_pc * 2];
			imem_ifun = memory[f_pc * 2 + 1];
		}

		//f_icode: Determine icode of fetched instruction
		//f_ifun: determin ifun
		if (imem_error)
			f_icode = INOP, f_ifun = FNONE;
		else
			f_icode = imem_icode, f_ifun = imem_ifun;

		//fetch icode & ifun
		sprintf(buffer, "icode:ifun <- M1[0x%x] = %x:%x = ", f_pc, f_icode, f_ifun);
		f_do.push_back(buffer + get_icode(f_icode) + ":" + get_ifun(f_icode, f_ifun));

		//Is instruction valid?
		instr_valid =
			f_icode == INOP && f_ifun == FNONE ||
			f_icode == IHALT && f_ifun == FNONE ||
			f_icode == IRRMOVL && f_ifun >= FJMP && f_ifun <= FJG ||
			f_icode == IIRMOVL && f_ifun == FNONE ||
			f_icode == IRMMOVL && f_ifun == FNONE ||
			f_icode == IMRMOVL && f_ifun == FNONE ||
			f_icode == IOPL && f_ifun <= FXORL && f_ifun >= FADDL ||
			f_icode == IJXX && f_ifun <= FJG && f_ifun >= FJMP ||
			f_icode == ICALL && f_ifun == FNONE ||
			f_icode == IRET && f_ifun == FNONE ||
			f_icode == IPUSHL && f_ifun == FNONE ||
			f_icode == IPOPL && f_ifun == FNONE ||
			f_icode == IIADDL && f_ifun == FNONE ||
			f_icode == ILEAVE && f_ifun == FNONE;

		//Determine status code for fetched instruction
		if (imem_error)
			f_stat = SADR;
		else
			if (!instr_valid)
				f_stat = SINS;
			else
				if (f_icode == IHALT)
					f_stat = SHLT;
				else
					f_stat = SAOK;//normal

		//Does fetched instruction require a reg-id byte?
		need_regids =
			f_icode == IRRMOVL ||
			f_icode == IOPL ||
			f_icode == IPUSHL ||
			f_icode == IPOPL ||
			f_icode == IIRMOVL ||
			f_icode == IRMMOVL ||
			f_icode == IMRMOVL ||
			f_icode == IIADDL;

		if (need_regids)
		{
			f_rA = memory[f_pc * 2 + 2];
			f_rB = memory[f_pc * 2 + 3];
			sprintf(buffer, "rA:rB <- M1[0x%x] = %x:%x = ", f_pc + 1, f_rA, f_rB);
			f_do.push_back(buffer + get_reg(f_rA) + ":" + get_reg(f_rB));
		}
		else
		{
			f_rA = f_rB = RNONE;
			f_do.push_back("rA:rB <- f:f = ENONE:ENONE");
		}

		//Does fetched instruction require a constant word?
		need_valC =
			f_icode == IIRMOVL ||
			f_icode == IRMMOVL ||
			f_icode == IMRMOVL ||
			f_icode == IJXX ||
			f_icode == ICALL ||
			f_icode == IIADDL;

		if (need_valC)
			if (need_regids)
			{
				f_valC = get_int(f_pc + 2);
				sprintf(buffer, "valC <- M4[0x%x] = %d", f_pc + 2, f_valC);
				f_do.push_back(buffer);
			}
			else
			{
				f_valC = get_int(f_pc + 1);
				sprintf(buffer, "valC <- M4[0x%x] = %d", f_pc + 1, f_valC);
				f_do.push_back(buffer);
			}

		//f_valP
		f_valP = f_pc + 1 + need_regids * 1 + need_valC * 4;
		sprintf(buffer, "valP <- 0x%x + %d = 0x%x", f_pc, 1 + need_regids * 1 + need_valC * 4, f_valP);
		f_do.push_back(buffer);

		//Predict next value of PC
		if (f_icode == IJXX || f_icode == ICALL)
			f_predPC = f_valC;
		else
			f_predPC = f_valP;

		V(&F_logic2control);
	}

	return NULL;
}

//void F_stage()
//{
//	F_value_update();
//	F_logic_update();
//}