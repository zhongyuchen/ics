#include "W_stage.h"
#include <iostream>
#include "global_variable.h"
#include "macro.h"
#include "struct.h"

using namespace std;

void write_int(int address, int value)//input theoretical address
{
	memory[address * 2 + 1] = value & 0xf;
	memory[address * 2 + 0] = (value >> 4) & 0xf;
	memory[address * 2 + 3] = (value >> 8) & 0xf;
	memory[address * 2 + 2] = (value >> 12) & 0xf;
	memory[address * 2 + 5] = (value >> 16) & 0xf;
	memory[address * 2 + 4] = (value >> 20) & 0xf;
	memory[address * 2 + 7] = (value >> 24) & 0xf;
	memory[address * 2 + 6] = (value >> 28) & 0xf;
}

void *W_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2W_reg);
		P(&reg2W_reg);

		//printf("---W_reg\n");
		if (W_bubble)
		{
			W_stat = SBUB;
			W_icode = INOP;
			W_valE = 0;
			W_valM = 0;
			W_dstE = RNONE;
			W_dstM = RNONE;
		}
		else
			if (W_stall)
				;
			else
			{
				W_stat = m_stat;
				W_icode = m_icode;
				W_valE = m_valE;
				W_valM = m_valM;
				W_dstE = m_dstE;
				W_dstM = m_dstM;
			}
		V(&W_reg2F_logic);
		V(&W_reg2D_logic);
		V(&W_reg2M_logic);
		V(&W_reg2W_logic);
	}

	return NULL;
}

void *W_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&W_reg2W_logic);
		//printf("---W_logic\n");
		//Update status of the processor
		if (W_stat == SBUB)
			Stat = SAOK, ins++;
		else
			Stat = W_stat;

		//exit or not?
		switch (Stat)
		{
		case SAOK:
			break;
		case SADR:case SINS:case SHLT:
			error = 1; break;
		}

		V(&W_logic2control);
	}

	return NULL;
}

//void W_stage()
//{
//	W_value_update();
//	W_logic_update();
//}