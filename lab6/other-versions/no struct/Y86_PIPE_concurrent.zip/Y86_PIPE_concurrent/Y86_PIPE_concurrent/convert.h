#pragma once

#include <string>

using namespace std;

int char_to_int(char c);
string get_reg(int reg_fun);
string get_icode(int icode);
string get_ifun(int icode, int ifun);
string get_stat(int stat);