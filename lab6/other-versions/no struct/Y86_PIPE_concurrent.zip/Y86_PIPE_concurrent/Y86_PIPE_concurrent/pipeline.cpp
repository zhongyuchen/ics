#include <iostream>
#include <string>
#include <Windows.h>
#include <process.h>
#include "pipeline.h"
#include "macro.h"
#include "global_variable.h"
#include "struct.h"
#include "convert.h"
#include "F_stage.h"
#include "D_stage.h"
#include "E_stage.h"
#include "M_stage.h"
#include "W_stage.h"
#include "simulator.h"
#include "output.h"


using namespace std;

void initialize()
{
	//F
	F_bubble = false;
	F_predPC = 0;
	F_stall = false;

	//f
	f_icode = INOP;
	f_ifun = FNONE;
	f_pc = 0;
	f_predPC = 0;
	f_rA = RNONE;
	f_rB = RNONE;
	f_stat = SAOK;
	f_valC = 0;
	f_valP = 0;

	//D
	D_bubble = false;
	D_icode = INOP;
	D_ifun = FNONE;
	D_rA = RNONE;
	D_rB = RNONE;
	D_stall = false;
	D_stat = SAOK;
	D_valC = 0;
	D_valP = 0;

	//d
	d_dstE = RNONE;
	d_dstM = RNONE;
	d_icode = INOP;
	d_ifun = FNONE;
	d_rvalA = 0;
	d_rvalB = 0;
	d_srcA = RNONE;
	d_srcB = RNONE;
	d_stat = SAOK;
	d_valA = 0;
	d_valB = 0;
	d_valC = 0;

	//E
	E_bubble = false;
	E_dstE = RNONE;
	E_dstM = RNONE;
	E_icode = INOP;
	E_ifun = FNONE;
	E_srcA = RNONE;
	E_srcB = RNONE;
	E_stall = false;
	E_stat = SAOK;
	E_valA = 0;
	E_valB = 0;
	E_valC = 0;

	//e
	e_Cnd = 1;
	e_dstE = RNONE;
	e_dstM = RNONE;
	e_icode = INOP;
	e_stat = SAOK;
	e_valA = 0;
	e_valE = 0;
	
	//M
	M_bubble = false;
	M_Cnd = 1;
	M_dstE = RNONE;
	M_dstM = RNONE;
	M_icode = INOP;
	M_ifun = FNONE;
	M_stall = false;
	M_stat = SAOK;
	M_valA = 0;
	M_valE = 0;

	//m
	m_dstE = RNONE;
	m_dstM = RNONE;
	m_icode = INOP;
	m_stat = SAOK;
	m_valE = 0;
	m_valM = 0;

	//W
	W_bubble = false;
	W_dstE = RNONE;
	W_dstM = RNONE;
	W_icode = INOP;
	W_stall = false;
	W_stat = SAOK;
	W_valE = 0;
	W_valM = 0;

	//imem
	imem_error = 0;
	imem_icode = INOP;
	imem_ifun = FNONE;

	//instr
	instr_valid = 0;

	//need
	need_regids = 0;
	need_valC = 0;

	//Stat
	Stat = SAOK;

	//alu
	alu_A = 0;
	alu_B = 0;
	alu_fun = ALUADD;
	alu_OF = 0;
	alu_SF = 0;
	alu_ZF = 0;
	
	//CC
	CC_OF = 0;
	CC_SF = 0;
	CC_ZF = 0;
	CC_set = 0;

	//dmem
	dmem_error = 0;

	//mem
	mem_addr = 0;
	mem_read = 0;
	mem_write = 0;

	//register file
	for (int i = 0; i < 16; i++)
		reg[i] = 0;

	//memory
	for (int i = 0; i < MEMORY_SIZE; i++)
		memory[i] = 0;

	//other variables
	PC = 0;
	error = 0;//abnormal exit
	ins = 0;
	CPI = 0;
	cycle = 0;

	//move
	seq_do.clear();
	m_do.clear();
	e_do.clear();
	d_do.clear();
	f_do.clear();
	//changed memory
	changed.clear();

	//initialize sem
	I(&control2dmem, 0);
	I(&control2CC, 0);
	I(&control2reg, 0);
	I(&control2F_reg, 0);
	I(&control2D_reg, 0);
	I(&control2E_reg, 0);
	I(&control2M_reg, 0);
	I(&control2W_reg, 0);

	I(&F_reg2F_logic, 0);
	I(&D_reg2D_logic, 0);
	I(&E_reg2E_logic, 0);
	I(&M_reg2M_logic, 0);
	I(&W_reg2W_logic, 0);

	I(&M_reg2F_logic, 0);
	I(&W_reg2F_logic, 0);

	I(&E_logic2D_logic, 0);
	I(&M_logic2D_logic, 0);
	I(&W_reg2D_logic, 0);

	I(&D_logic2control, 0);
	I(&E_logic2control, 0);
	I(&M_logic2control, 0);
	I(&W_logic2control, 0);

	I(&dmem2M_reg, 0);
	I(&CC2E_logic, 0);
	I(&reg2D_logic, 0);

	I(&D_reg2F_logic, 0);
	I(&E_reg2D_logic, 0);
	I(&M_reg2E_logic, 0);
	I(&W_reg2M_logic, 0);

	I(&reg2W_reg, 0);
}

void control_update()
{
//F
	//bubble or stall
	//F_bubble = 0;//not exist
	F_stall = (E_icode == IMRMOVL || E_icode == IPOPL || E_icode == ILEAVE) && (E_dstM == d_srcA || E_dstM == d_srcB) || (IRET == D_icode || IRET == E_icode || IRET == M_icode);

//D
	//Mispredicted branch					Stalling at fetch while ret passes through pipeline, but not condition for a load / use hazard
	D_bubble = (E_icode == IJXX && !e_Cnd) ||
		!((E_icode == IMRMOVL || E_icode == IPOPL || E_icode == ILEAVE) && (E_dstM == d_srcA || E_dstM == d_srcB)) &&
			(IRET == D_icode || IRET == E_icode || IRET == M_icode);

	//Conditions for a load/use hazard
	D_stall = (E_icode == IMRMOVL || E_icode == IPOPL || E_icode == ILEAVE) && 
		(E_dstM == d_srcA || E_dstM == d_srcB);

//E
	//E_stall = 0;
	E_bubble = (E_icode == IJXX && !e_Cnd) || 
		(E_icode == IMRMOVL || E_icode == IPOPL || E_icode == ILEAVE) &&
		(E_dstM == d_srcA || E_dstM == d_srcB);

//M
	M_bubble = (m_stat == SADR || m_stat == SINS || m_stat == SHLT) ||
		(W_stat == SADR || W_stat == SINS || W_stat == SHLT);
	//M_stall = 0;

//W
	W_stall = W_stat == SADR || W_stat == SINS || W_stat == SHLT;
	//W_bubble = 0;
}

//thread functions
void *dmem_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		//HANG THE DMEM THREAD
		P(&control2dmem);
		//printf("---dmem\n");
		
		seq_do.clear();

		//dmemory
		if (!dmem_error && M_stat != SBUB && mem_write)
		{
			//data update
			write_int(mem_addr, M_valA);//sequential: write memory at the end of the stage
			m_valM = 0;//if it's write memory, there is no need to get data from memor, so make it NULL

					   //sequential update section
			sprintf(buffer, "M4[0x%x] <- %d", mem_addr, M_valA);
			seq_do.push_back(buffer);

			//changed memory section
			changed[mem_addr] = M_valA;
		}

		V(&dmem2M_reg);
	}

	return NULL;
}

void *CC_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		P(&control2CC);
		//printf("---CC\n");
		
		seq_do.clear();

		//CC
		if (CC_set)
		{
			//CC update
			CC_OF = alu_OF;
			CC_SF = alu_SF;
			CC_ZF = alu_ZF;

			//sequential update section
			sprintf(buffer, "ZF <- %-11d  SF <- %-11d  OF <- %-11d ", CC_ZF, CC_SF, CC_OF);
			seq_do.push_back(buffer);
		}

		V(&CC2E_logic);
	}

	return NULL;
}

void *reg_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	string s;
	char buffer[LENGTH + 10];

	while (1)
	{
		P(&control2reg);
		//printf("---reg\n");
		
		seq_do.clear();

		//register file (sequential, write register at the end of the stage)
		if (W_stat == SAOK || W_stat == SBUB)
		{
			if (W_dstE != RNONE)//reg[W_dstE]
			{
				reg[W_dstE] = W_valE;
				s = "R[" + get_reg(W_dstE) + "] <- ";
				sprintf(buffer, "%d", W_valE);
				s += buffer;
				seq_do.push_back(s);
			}

			if (W_dstM != RNONE)//reg[W.dstM]
			{
				reg[W_dstM] = W_valM;
				s = "R[" + get_reg(W_dstM) + "] <- ";
				sprintf(buffer, "%d", W_valM);
				s += buffer;
				seq_do.push_back(s);
			}
		}

		V(&reg2W_reg);
		V(&reg2D_logic);
	}

	return NULL;
}

void sequential_update()
{
//	dmem_update();
//	CC_update();
//	reg_update();
}

void posedge_edge_clock()
{
//	//cycle count
//	cycle++;
//
//	//update sequential components: CC, memory, reg files
//	dmem_update();
//	CC_update();
//	reg_update();
//	W_value_update();
//	M_value_update();
//	E_value_update();
//	D_value_update();
//	F_value_update();
//
//	//5 stages
//	W_logic_update();
//
//	M_logic_update();
//
//	E_logic_update();
//
//	D_logic_update();
//
//	F_logic_update();
//
//	//update every stage's need of bubble or stall for the next coming stage
//	control_update();
//
//	//print reg file, CC, PC, and every stage's registers
//	table();
}

void run()
{
	while (1)
	{
		Sleep(8000 - speed);
		posedge_edge_clock();
		if (error)
		{
			error = 0;
			return;
		}
	}
}

void concurrent_run()
{
	//create peer threads
	pthread_create(&tid[0], NULL, dmem_update, NULL);
	pthread_create(&tid[1], NULL, CC_update, NULL);
	pthread_create(&tid[2], NULL, reg_update, NULL);

	pthread_create(&tid[3], NULL, F_value_update, NULL);
	pthread_create(&tid[4], NULL, F_logic_update, NULL);

	pthread_create(&tid[5], NULL, D_value_update, NULL);
	pthread_create(&tid[6], NULL, D_logic_update, NULL);

	pthread_create(&tid[7], NULL, E_value_update, NULL);
	pthread_create(&tid[8], NULL, E_logic_update, NULL);

	pthread_create(&tid[9], NULL, M_value_update, NULL);
	pthread_create(&tid[10], NULL, M_logic_update, NULL);

	pthread_create(&tid[11], NULL, W_value_update, NULL);
	pthread_create(&tid[12], NULL, W_logic_update, NULL);

	while (!error)
	{
		//printf("here-2\n");
		cycle++;

		//KICK START the first clock cycle
		V(&control2dmem); //printf("here0\n");
		V(&control2CC); //printf("here1\n");
		V(&control2reg); //printf("here2\n");
		V(&control2F_reg); //printf("here3\n");
		V(&control2D_reg); //printf("here4\n");
		V(&control2E_reg); //printf("here5\n");
		V(&control2M_reg); //printf("here6\n");
		V(&control2W_reg); //printf("here7\n");
		
		P(&F_logic2control); //printf("here1\n");
		P(&D_logic2control); //printf("here2\n");
		P(&E_logic2control); //printf("here3\n");
		P(&M_logic2control);
		P(&W_logic2control);

		//printf("---control\n");

		//the last thread
		control_update();
		//output result
		table();
	}

	for (int i = 0; i < NUM_THREAD; i++)
		pthread_cancel(tid[i]);

	return;
}

void I(sem_t *sem, unsigned int value)
{
	sem_init(sem, 0, value);
	//cout << "Initialize" << sem << endl;
	return;
}

void P(sem_t *sem)
{
	sem_wait(sem);
	//cout << "P" <<sem<< endl;
	return;
}

void V(sem_t *sem)
{
	sem_post(sem);
	//cout << "V" <<sem<< endl;
	return;
}