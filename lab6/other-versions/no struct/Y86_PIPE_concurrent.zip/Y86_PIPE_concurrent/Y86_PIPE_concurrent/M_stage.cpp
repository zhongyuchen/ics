#include <iostream>
#include "M_stage.h"
#include "macro.h"
#include "struct.h"
#include "global_variable.h"
#include "convert.h"
#include <string>

using namespace std;

bool check_segmentation(int pc)//input real address
{
	if ((pc+4) * 2 < MEMORY_SIZE && pc * 2 >= 0)
		return 0;
	return 1;//segmentation
}

//get an integer from instruction memory
int get_int(int address)//input theoretical address
{
	int ret = 0;
	ret ^= (memory[address * 2 + 1] << 0) & 0xf;
	ret ^= (memory[address * 2 + 0] << 4) & 0xf0;
	ret ^= (memory[address * 2 + 3] << 8) & 0xf00;
	ret ^= (memory[address * 2 + 2] << 12) & 0xf000;
	ret ^= (memory[address * 2 + 5] << 16) & 0xf0000;
	ret ^= (memory[address * 2 + 4] << 20) & 0xf00000;
	ret ^= (memory[address * 2 + 7] << 24) & 0xf000000;
	ret ^= (memory[address * 2 + 6] << 28) & 0xf0000000;
	return ret;
}

void *M_value_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	while (1)
	{
		P(&control2M_reg);
		P(&dmem2M_reg);

		//printf("---M_reg\n");
		if (M_bubble)
		{
			M_stat = SBUB;
			M_icode = INOP;
			M_Cnd = 1;//normal
			M_valE = 0;
			M_valA = 0;
			M_dstE = RNONE;
			M_dstM = RNONE;
		}
		else
			if (M_stall)
				;
			else
			{
				M_stat = e_stat;
				M_icode = e_icode;
				M_Cnd = e_Cnd;
				M_valE = e_valE;
				M_valA = e_valA;
				M_dstE = e_dstE;
				M_dstM = e_dstM;
			}
		V(&M_reg2F_logic);
		V(&M_reg2M_logic);
		V(&M_reg2E_logic);
	}

	return NULL;
}

void *M_logic_update(void *vargp)
{
	pthread_detach(pthread_self());
	
	char buffer[LENGTH + 10];
	
	while (1)
	{
		P(&M_reg2M_logic);
		P(&W_reg2M_logic);

		//printf("---M_logic\n");
		m_do.clear();

		//mem_addr
		switch (M_icode)
		{
		case IRMMOVL:case IPUSHL:case ICALL:case IMRMOVL:
			mem_addr = M_valE; break;
		case IPOPL:case IRET:case ILEAVE:
			mem_addr = M_valA; break;
		default:
			break;
		}

		//(either one below can be TRUE)
		//Set read control signal
		mem_read = M_icode == IMRMOVL || M_icode == IPOPL || M_icode == IRET || M_icode == ILEAVE;
		//Set write control signal
		mem_write = M_icode == IRMMOVL || M_icode == IPUSHL || M_icode == ICALL;

		//dmem_error
		if (mem_read || mem_write)
			dmem_error = check_segmentation(mem_addr);
		else
			dmem_error = 0;

		//m_stat
		if (dmem_error)
			m_stat = SADR;
		else
			m_stat = M_stat;

		m_icode = M_icode;
		m_valE = M_valE;
		m_dstE = M_dstE;
		m_dstM = M_dstM;

		//read m_valM in memory with address of mem_addr
		if (!dmem_error&&mem_read)//no data memory error && need to read memory
		{
			m_valM = get_int(mem_addr);
			sprintf(buffer, "valM <- M4[0x%x] = %d", mem_addr, get_int(mem_addr));
			m_do.push_back(buffer);
		}

		V(&M_logic2D_logic);
		V(&M_logic2control);
	}

	return NULL;
}

//void M_stage()
//{
//	M_value_update();
//	M_logic_update();
//}