#pragma once

#include "macro.h"
#include <vector>
#include <string>
#include <Windows.h>
#include <fstream>
#include <map>
#include "pipeline.h"

using namespace std;

extern int F_predPC;
extern bool F_bubble;
extern bool F_stall;

extern int f_icode;
extern int f_ifun;
extern int f_valC;
extern int f_valP;
extern int f_pc;
extern int f_stat;
extern int f_predPC;
extern int f_rA;
extern int f_rB;

extern int need_valC;
extern int need_regids;

extern bool instr_valid;

extern int imem_icode;
extern int imem_ifun;
extern bool imem_error;

extern int D_stat;
extern int D_icode;
extern int D_ifun;
extern int D_rA;
extern int D_rB;
extern int D_valC;
extern int D_valP;
extern bool D_bubble;
extern bool D_stall;

extern int d_srcA;
extern int d_srcB;
extern int d_dstE;
extern int d_dstM;
extern int d_valA;
extern int d_valB;
extern int d_rvalA;
extern int d_rvalB;
extern int d_stat;
extern int d_icode;
extern int d_ifun;
extern int d_valC;

extern int E_stat;
extern int E_icode;
extern int E_ifun;
extern int E_valC;
extern int E_valA;
extern int E_valB;
extern int E_dstE;
extern int E_dstM;
extern int E_srcA;
extern int E_srcB;
extern bool E_bubble;
extern bool E_stall;

extern int e_valE;
extern int e_dstE;
extern int e_dstM;
extern int e_valA;
extern int e_stat;
extern int e_icode;
extern bool e_Cnd;

extern int alu_A;
extern int alu_B;
extern int alu_fun;
extern bool alu_ZF;
extern bool alu_SF;
extern bool alu_OF;

extern bool CC_ZF;//zero flag
extern bool CC_SF;//sign flag
extern bool CC_OF;//overflow flag
extern bool CC_set;

extern int M_stat;
extern int M_icode;
extern int M_ifun;
extern int M_Cnd;
extern int M_valE;
extern int M_valA;
extern int M_dstE;
extern int M_dstM;
extern bool M_bubble;
extern bool M_stall;

extern bool dmem_error;

extern int mem_addr;
extern bool mem_read;
extern bool mem_write;

extern int m_valM;
extern int m_stat;
extern int m_icode;
extern int m_valE;
extern int m_dstE;
extern int m_dstM;

extern int W_stat;
extern int W_icode;
extern int W_valE;
extern int W_valM;
extern int W_dstE;
extern int W_dstM;
extern bool W_stall;
extern bool W_bubble;

extern int input;
extern int ins;
extern double CPI;
extern int speed;
extern int output;
extern int save;
extern int PC;
//clock cycle
extern int cycle;
extern bool error;//abnormal exit
//Stat: the actual state of the process
extern int Stat;

//memory
extern int memory[MEMORY_SIZE];
//register file
extern int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
extern vector<string> seq_do;
extern vector<string> m_do;
extern vector<string> e_do;
extern vector<string> d_do;
extern vector<string> f_do;
//changed memory
extern map<int, int> changed;

//file output
extern ofstream fout;

extern pthread_t tid[NUM_THREAD];

extern sem_t control2dmem, control2CC, control2reg;
extern sem_t control2F_reg, control2D_reg, control2E_reg, control2M_reg, control2W_reg;
extern sem_t F_reg2F_logic, D_reg2D_logic, E_reg2E_logic, M_reg2M_logic, W_reg2W_logic;

extern sem_t F_logic2control, D_logic2control, E_logic2control, M_logic2control, W_logic2control;

extern sem_t M_reg2F_logic, W_reg2F_logic;
extern sem_t E_logic2D_logic, M_logic2D_logic, W_reg2D_logic;

extern sem_t dmem2M_reg, CC2E_logic, reg2D_logic;

extern sem_t D_reg2F_logic, E_reg2D_logic, M_reg2E_logic, W_reg2M_logic;

extern sem_t reg2W_reg;