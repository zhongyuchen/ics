#pragma once

class M_register
{
public:
	int stat;
	int icode;
	int ifun;
	int Cnd;
	int valE;
	int valA;
	int dstE;
	int dstM;
	bool bubble;
	bool stall;

	bool check_segmentation(int pc);//input real address
	void M_value_update();
	void M_logic_update();
	void M_stage();
	int get_int(int address);
};

class m_value
{
public:
	int valM;
	int stat;
	int icode;
	int valE;
	int dstE;
	int dstM;
};

class dmem_value
{
public:
	bool error;
};

class mem_value
{
public:
	int addr;
	bool read;
	bool write;
};