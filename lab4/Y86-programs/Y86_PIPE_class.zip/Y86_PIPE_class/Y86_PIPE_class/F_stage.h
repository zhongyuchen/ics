#pragma once

class F_register
{
public:
	int predPC;
	bool bubble;
	bool stall;

	void F_value_update();
	void F_logic_update();
	void F_stage();
};

class f_value
{
public:
	int icode;
	int ifun;
	int valC;
	int valP;
	int pc;
	int stat;
	int predPC;
	int rA;
	int rB;
};

class need_value
{
public:
	int valC;
	int regids;
};
class instr_value
{
public:
	bool valid;
};

class imem_value
{
public:
	int icode;
	int ifun;
	bool error;
};