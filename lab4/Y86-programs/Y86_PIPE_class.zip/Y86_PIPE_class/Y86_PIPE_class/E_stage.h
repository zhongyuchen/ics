#pragma once

class E_register
{
public:
	int stat;
	int icode;
	int ifun;
	int valC;
	int valA;
	int valB;
	int dstE;
	int dstM;
	int srcA;
	int srcB;
	bool bubble;
	bool stall;

	void ALU();
	void E_value_update();
	void E_logic_update();
	void E_stage();
};

class e_value
{
public:
	int valE;
	int dstE;
	int dstM;
	int valA;
	int stat;
	int icode;
	bool Cnd;
};

class alu_logic
{
public:
	int A;
	int B;
	int fun;
	bool ZF;
	bool SF;
	bool OF;
};

class CC_register
{
public:
	bool ZF;//zero flag
	bool SF;//sign flag
	bool OF;//overflow flag
	bool set;
};