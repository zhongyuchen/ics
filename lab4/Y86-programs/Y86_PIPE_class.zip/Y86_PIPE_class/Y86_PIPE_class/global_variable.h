#pragma once

#include "macro.h"
#include <vector>
#include <string>
#include <Windows.h>
#include <fstream>
#include <map>
#include "F_stage.h"
#include "D_stage.h"
#include "E_stage.h"
#include "M_stage.h"
#include "W_stage.h"
#include "pipeline.h"

using namespace std;

extern F_register F;
extern f_value f;
extern need_value need;
extern instr_value instr;
extern imem_value imem;
extern D_register D;
extern d_value d;
extern E_register E;
extern e_value e;
extern alu_logic alu;
extern CC_register CC;
extern M_register M;
extern dmem_value dmem;
extern mem_value mem;
extern m_value m;
extern W_register W;

extern int input;
extern int ins;
extern double CPI;
extern int speed;
extern int output;
extern int save;
extern int PC;
//clock cycle
extern int cycle;
extern bool error;//abnormal exit
//Stat: the actual state of the process
extern int Stat;

//memory
extern int memory[MEMORY_SIZE];
//register file
extern int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
extern vector<string> seq_do;
extern vector<string> m_do;
extern vector<string> e_do;
extern vector<string> d_do;
extern vector<string> f_do;
//changed memory
extern map<int, int> changed;

//file output
extern ofstream fout;