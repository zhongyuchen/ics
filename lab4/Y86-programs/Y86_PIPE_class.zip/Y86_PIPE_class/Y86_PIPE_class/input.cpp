#include <iostream>
#include "convert.h"
#include "global_variable.h"
#include "input.h"

using namespace std;

int char_to_int(char c)
{
	if (c >= '0'&&c <= '9')
		return c - '0';
	if (c >= 'a'&&c <= 'f')
		return c - 'a' + 10;
	if (c >= 'A'&&c <= 'F')
		return c - 'A' + 10;
	return 0;
}

void hex_input()
{
	char c;
	int length = 0;
	while (cin >> c)
	{
		if (c >= '0'&&c <= '9' || c >= 'a'&&c <= 'f' || c >= 'A'&&c <= 'F')
			memory[length++] = char_to_int(c);
	}
}

void binary_input()
{
	char c;
	int i, k, length = 0;
	do
	{
		for (i = 0, k = 0; i < 4 && (c = getchar()); i++)
			k = k * 2 + c - '0';
		if (c != EOF)
			memory[length++] = k;
	} while (c != EOF);
}

void yo_input()
{
	char c;
	string line;
	int length = 0, i;
	int line_size;

	while (getline(cin, line))
	{
		line_size = line.size();
		for (i = 0; i < line_size && line[i] != ':' && line[i] != '|'; i++)
			;
		for (; i < line_size && line[i] != '|'; i++)
		{
			c = line[i];
			if (c >= '0'&&c <= '9' || c >= 'a'&&c <= 'f' || c >= 'A'&&c <= 'F')
				memory[length++] = char_to_int(c);
		}
	}
}