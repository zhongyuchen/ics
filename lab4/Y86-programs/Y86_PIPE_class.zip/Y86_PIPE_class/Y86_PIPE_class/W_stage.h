#pragma once

class W_register
{
public:
	int stat;
	int icode;
	int valE;
	int valM;
	int dstE;
	int dstM;
	bool stall;
	bool bubble;

	void W_value_update();
	void W_logic_update();
	void W_stage();
	void write_int(int address, int value);
};