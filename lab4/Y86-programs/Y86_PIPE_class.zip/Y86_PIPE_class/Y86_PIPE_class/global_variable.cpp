#include "global_variable.h"
#include "macro.h"
#include <vector>
#include <string>
#include <fstream>
#include <Windows.h>
#include <map>
#include "convert.h"
#include "F_stage.h"
#include "D_stage.h"
#include "E_stage.h"
#include "M_stage.h"
#include "pipeline.h"

using namespace std;

//structures
F_register F;
f_value f;
need_value need;
instr_value instr;
imem_value imem;
D_register D;
d_value d;
E_register E;
e_value e;
alu_logic alu;
CC_register CC;
M_register M;
dmem_value dmem;
mem_value mem;
m_value m;
W_register W;

int PC;
//clock cycle
int cycle;
//abnormal exit
bool error;
//Stat: the actual state of the process
int Stat;
int input;
int ins;
double CPI;
int speed;
int output;
int save;

//memory
int memory[MEMORY_SIZE];
//register file
int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
vector<string> seq_do;
vector<string> m_do;
vector<string> e_do;
vector<string> d_do;
vector<string> f_do;
//changed memory
map<int, int> changed;

//file output
ofstream fout;