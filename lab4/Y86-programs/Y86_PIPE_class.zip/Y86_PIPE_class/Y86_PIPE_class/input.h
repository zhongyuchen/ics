#pragma once

#include "input.h"

int char_to_int(char c);
void hex_input();
void binary_input();
void yo_input();