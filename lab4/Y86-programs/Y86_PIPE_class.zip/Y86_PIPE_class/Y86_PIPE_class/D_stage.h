#pragma once

class D_register
{
public:
	int stat;
	int icode;
	int ifun;
	int rA;
	int rB;
	int valC;
	int valP;
	bool bubble;
	bool stall;

	void D_value_update();
	void D_logic_update();
	void D_stage();
};

class d_value
{
public:
	int srcA;
	int srcB;
	int dstE;
	int dstM;
	int valA;
	int valB;
	int rvalA;
	int rvalB;
	int stat;
	int icode;
	int ifun;
	int valC;
};