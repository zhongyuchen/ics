#include <iostream>
#include <vector>
#include <string>
#include <string>
#include <fstream>
#include <Windows.h>
#include "global_variable.h"
#include "convert.h"
#include "macro.h"
#include "simulator.h"
#include "pipeline.h"
#include "input.h"

using namespace std;

void simulator()
{
	int i;
	char filename[100];
	FILE *fp;
	string s;

	//title
	BLUE;
	printf("Y86 Pipeline@Zhongyu Chen\n");
	printf("Serial number 16307130194\n");
	GREEN;
	printf("Starting...\n");
	CYAN;
	printf("Features\n");
	printf("1.Storing: Little Endian\n");
	printf("2.Architecture: Von Neumann\n");
	printf("3.Width: 32 bits\n");
	printf("4.ROM: 134,217,728 B\n");
	printf("5.Instructions: halt, nop, rrmovl, irmovl, rmmovl, mrmovl, cmovxx, opl, jxx, call, ret, push, pop, push\n");
	GREEN;
	printf("Successful!\n");

	//run UI
	while (1)
	{
		initialize();
		
		//exit
		YELLOW;
		printf("Do you want to exit or continue?(default as 0)\n");
		printf("0.continue\n");
		printf("1.exit\n");
		WHITE;
		cin.clear();
		cin >> i;
		if (i)
			break;

		GREEN;
		printf("Continuing...\n");

		//begin
		BLUE;
		printf("Please follow the instructions and input the number of the operation!\n");

		//input mode
		YELLOW;
		printf("Choose input mode(default as 0)\n");
		printf("0.input .yo file\n");
		printf("1.input binary file\n");
		printf("2.input hexadecimal file\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:input = YO; break;
		case 1:input = BIN; break;
		case 2:input = HEX; break;
		default:input = YO; break;
		}

		//output mode
		YELLOW;
		printf("Choose output mode(default as 0)\n");
		printf("0.rolling mode\n");
		printf("1.still mode(this mode can only run program once)\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:output = ROL; break;
		case 1:output = STI; break;
		default:output = 0;
		}

		//speed
		YELLOW;
		printf("Input speed of running programs(0~8000, slow to fast)\n");
		WHITE;
		cin >> speed;
		if (speed < 0)
			speed = 0;
		else
			if (speed > 8000)
				speed = 8000;

		//save file?
		YELLOW;
		printf("Do you want to save as output.txt?(default as 0)\n");
		printf("0.view only\n");
		printf("1.save as well\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:save = SEE; break;
		case 1:save = SAV; break;
		default:save = SEE;
		}

		//input file
		YELLOW;
		printf("Input the route of the file\n");
		WHITE;
		cin.clear();
		cin >> filename;
		if ((fp = fopen(filename, "rb")) == NULL)
		{
			RED;
			printf("%s: No such file or directory\n", filename);
			cin.clear();
			continue;
		}
		else
		{
			freopen(filename, "rb", stdin);
			switch (input)
			{
			case YO:yo_input(); break;
			case BIN:binary_input(); break;
			case HEX:hex_input(); break;
			}
			fclose(fp);

			GREEN;
			printf("Successful!\n");
		}

		//print the head
		if (save == SAV)
		{
			for (i = 0, s = ""; filename[i] != '.'; i++)
				s += filename[i];
			s += "-output.txt";
			fout.open(s.c_str());
			fout << "-----------------------------------------------------------" << endl;
			fout << "Running program in " << filename << endl;
			fout << "-----------------------------------------------------------" << endl;
			fout << endl << endl << endl;
		}

		//click to run
		YELLOW;
		printf("Type in any char to run\n");
		freopen("CON", "r", stdin);
		char c = getchar();

		//running
		WHITE;
		run();

		//ended
		GREEN;
		printf("Program ended!\n");
		cin.clear();

		//close the output progress to file
		if (output == SAV)
			fout.close();

		WHITE;
	}

	GREEN;
	printf("Y86 Pipeline Processor has ended!\n");
	WHITE;
}