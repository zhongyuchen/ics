#include <string>
#include "convert.h"
#include "global_variable.h"

using namespace std;

string get_reg(int reg_fun)
{
	switch (reg_fun)
	{
	case EAX: return "%eax";
	case ECX: return "%ecx";
	case EDX: return "%edx";
	case EBX: return "%ebx";
	case ESP: return "%esp";
	case EBP: return "%ebp";
	case ESI: return "%esi";
	case EDI: return "%edi";
	case E8: return "%e8";
	case E9: return "%e9";
	case E10: return "%e10";
	case E11: return "%e11";
	case E12: return "%e12";
	case E13: return "%e13";
	case E14: return "%e14";
	case ENONE: return "ENONE";//not exist
	default: return "ERROR";
	}
}

string get_icode(int icode)
{
	switch (icode)
	{
	case IHALT:return "IHALT";
	case INOP:return "INOP";
	case IRRMOVL:return "IRRMOVL";
	case IIRMOVL:return "IIRMOVL";
	case IRMMOVL:return "IRMMOVL";
	case IMRMOVL:return "IMRMOVL";
	case IOPL:return "IOPL";
	case IJXX:return "IJXX";
	case ICALL:return "ICALL";
	case IRET:return "IRET";
	case IPUSHL:return "IPUSHL";
	case IPOPL:return "IPOPL";
	case IIADDL:return "IIADDL";
	case ILEAVE:return "ILEAVE";
	default:return "ERROR";
	}
}

string get_ifun(int icode, int ifun)
{
	//1.icode IOPL
	if (icode == IOPL)
	{
		switch (ifun)
		{
		case FADDL:return "FADDL";
		case FSUBL:return "FSUBL";
		case FANDL:return "FANDL";
		case FXORL:return "FXORL";
		default:return "ERROR";
		}
	}

	//2.icode IJXX or IRRMOVL
	if (icode == IJXX || icode == IRRMOVL)
	{
		switch (ifun)
		{
		case FJMP:return "FJMP";
		case FJLE:return "FJLE";
		case FJL:return "FJL";
		case FJE:return "FJE";
		case FJNE:return "FJNE";
		case FJGE:return "FJGE";
		case FJG:return "FJG";
		default:return "ERROR";
		}
	}

	//3.icode default
	switch (ifun)
	{
	case FNONE:return "FNONE";
	default:return "ERROR";
	}
}

string get_stat(int stat)
{
	switch (stat)
	{
	case SBUB:return "SBUB";//bubble
	case SAOK:return "SAOK";//normal
	case SADR:return "SADR";//address abnormal
	case SINS:return "SINS";//instruction abnormal
	case SHLT:return "SHLT";//halt
	default:return "ERROR";
	}
}