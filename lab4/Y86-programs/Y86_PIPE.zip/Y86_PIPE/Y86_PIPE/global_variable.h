#pragma once

#include "macro.h"
#include <vector>
#include <string>
#include <Windows.h>
#include <fstream>
#include <map>

using namespace std;

extern struct F_register F;
extern struct f_value f;
extern struct need_value need;
extern struct instr_value instr;
extern struct imem_value imem;
extern struct D_register D;
extern struct d_value d;
extern struct E_register E;
extern struct e_value e;
extern struct alu_logic alu;
extern struct CC_register CC;
extern struct M_register M;
extern struct dmem_value dmem;
extern struct mem_value mem;
extern struct m_value m;
extern struct W_register W;

extern int input;
extern int ins;
extern double CPI;
extern int speed;
extern int output;
extern int save;
extern int PC;
//clock cycle
extern int cycle;
extern bool error;//abnormal exit
//Stat: the actual state of the process
extern int Stat;

//memory
extern int memory[MEMORY_SIZE];
//register file
extern int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
extern vector<string> seq_do;
extern vector<string> m_do;
extern vector<string> e_do;
extern vector<string> d_do;
extern vector<string> f_do;
//changed memory
extern map<int, int> changed;

//file output
extern ofstream fout;