#include "D_stage.h"
#include <iostream>
#include "macro.h"
#include "global_variable.h"
#include "struct.h"
#include "convert.h"

using namespace std;

void D_value_update()//the data from F goes in D register
{
	if (D.bubble)
	{
		D.stat = SBUB;
		D.icode = INOP;
		D.ifun = FNONE;
		D.rA = RNONE;
		D.rB = RNONE;
		D.valC = 0;
		D.valP = 0;
	}
	else
		if (D.stall)//stall: keep the value not changed
			;
		else//pass on the values from f
		{
			D.stat = f.stat;
			D.icode = f.icode;
			D.ifun = f.ifun;
			D.rA = f.rA;
			D.rB = f.rB;
			D.valC = f.valC;
			D.valP = f.valP;
		}
}

void D_logic_update()
{
	char buffer[LENGTH + 10];
	d_do.clear();
	
	d.stat = D.stat;
	d.icode = D.icode;
	d.ifun = D.ifun;
	d.valC = D.valC;

	//d.srcA
	switch (D.icode)
	{
	case IRRMOVL:case IRMMOVL:case IOPL:case IPUSHL:case IIADDL:
		d.srcA = D.rA; break;
	case IPOPL:case IRET:
		d.srcA = RRSP; break;
	case ILEAVE:
		d.srcA = EBP; break;
	default:
		d.srcA = RNONE; break;
	}

	//d.srcB
	switch (D.icode)
	{
	case IOPL:case IRMMOVL:case IMRMOVL:case IIADDL:
		d.srcB = D.rB; break;
	case IPUSHL:case IPOPL:case ICALL:case IRET:
		d.srcB = RRSP; break;
	case ILEAVE:
		d.srcB = EBP; break;
	default:
		d.srcB = RNONE; break;
	}

	//d.dstE
	switch (D.icode)
	{
	case IRRMOVL:case IIRMOVL:case IOPL:case IIADDL:
		d.dstE = D.rB; break;
	case IPUSHL:case IPOPL:case ICALL:case IRET:case ILEAVE:
		d.dstE = RRSP; break;
	default:
		d.dstE = RNONE; break;
	}

	//d.dstM
	switch (D.icode)
	{
	case IMRMOVL:case IPOPL:
		d.dstM = D.rA; break;
	case ILEAVE:
		d.dstM = EBP; break;
	default:
		d.dstM = RNONE; break;
	}

	//d.rvalA, d.rvalB
	d.rvalA = reg[d.srcA];
	d.rvalB = reg[d.srcB];

	//d.valA (Forward into decode stage for valA)
	if (D.icode == ICALL || D.icode == IJXX)//Use incremented PC
	{
		d.valA = D.valP;
		sprintf(buffer, "valA <- D.valP = %d", D.valP);
		d_do.push_back(buffer);
	}
	else
		if (d.srcA == e.dstE)//forward valE from execute
		{
			d.valA = e.valE;
			sprintf(buffer, "valA <- e.valE = %d", e.valE);
			d_do.push_back(buffer);
		}
		else
			if (d.srcA == M.dstM)//forward valM from memory
			{
				d.valA = m.valM;
				sprintf(buffer, "valA <- m.valM = %d", m.valM);
				d_do.push_back(buffer);
			}
			else
				if (d.srcA == M.dstE)//Forward valE from memory
				{
					d.valA = M.valE;
					sprintf(buffer, "valA <- M.valE = %d", M.valE);
					d_do.push_back(buffer);
				}
				else
					if (d.srcA == W.dstM)//Forward valM from write back
					{
						d.valA = W.valM;
						sprintf(buffer, "valA <- W.valM = %d", W.valM);
						d_do.push_back(buffer);
					}
					else
						if (d.srcA == W.dstE)//Forward valE from write back
						{
							d.valA = W.valE;
							sprintf(buffer, "valA <- W.valE = %d", W.valE);
							d_do.push_back(buffer);
						}
						else//Use value read from register file
						{
							d.valA = d.rvalA;
							sprintf(buffer, "%d", reg[d.srcA]);
							d_do.push_back("valA <- R[" + get_reg(d.srcA) + "] = " + buffer);
						}

	//d.valB
	if (d.srcB == e.dstE)//Forward valE from execute
	{
		d.valB = e.valE;
		sprintf(buffer, "valB <- e.valE = %d", e.valE);
		d_do.push_back(buffer);
	}
	else
		if (d.srcB == M.dstM)//Forward valM from memory
		{
			d.valB = m.valM;
			sprintf(buffer, "valB <- m.valM = %d", m.valM);
			d_do.push_back(buffer);
		}
		else
			if (d.srcB == M.dstE)//Forward valE from memory
			{
				d.valB = M.valE;
				sprintf(buffer, "valB <- M.valE = %d", M.valE);
				d_do.push_back(buffer);
			}
			else
				if (d.srcB == W.dstM)//Forward valM from write back
				{
					d.valB = W.valM;
					sprintf(buffer, "valB <- W.valM = %d", W.valM);
					d_do.push_back(buffer);
				}
				else
					if (d.srcB == W.dstE)//Forward valE from write back
					{
						d.valB = W.valE;
						sprintf(buffer, "valB <- W.valE = %d", W.valE);
						d_do.push_back(buffer);
					}
					else//Use value read from register file
					{
						d.valB = d.rvalB;
						sprintf(buffer, "%d", reg[d.srcB]);
						d_do.push_back("valB <- R[" + get_reg(d.srcB) + "] = " + buffer);
					}
}

void D_stage()
{
	D_value_update();
	D_logic_update();
}