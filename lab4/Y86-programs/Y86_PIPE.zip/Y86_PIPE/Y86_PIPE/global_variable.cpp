#include "global_variable.h"
#include "struct.h"
#include "macro.h"
#include <vector>
#include <string>
#include <fstream>
#include <Windows.h>
#include <map>

using namespace std;

//structures
struct F_register F = F_register();
struct f_value f = f_value();
struct need_value need = need_value();
struct instr_value instr = instr_value();
struct imem_value imem = imem_value();
struct D_register D = D_register();
struct d_value d = d_value();
struct E_register E = E_register();
struct e_value e = e_value();
struct alu_logic alu = alu_logic();
struct CC_register CC = CC_register();
struct M_register M = M_register();
struct dmem_value dmem = dmem_value();
struct mem_value mem = mem_value();
struct m_value m = m_value();
struct W_register W = W_register();

int PC;
//clock cycle
int cycle;
//abnormal exit
bool error;
//Stat: the actual state of the process
int Stat;
int input;
int ins;
double CPI;
int speed;
int output;
int save;

//memory
int memory[MEMORY_SIZE];
//register file
int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
vector<string> seq_do;
vector<string> m_do;
vector<string> e_do;
vector<string> d_do;
vector<string> f_do;
//changed memory
map<int, int> changed;

//file output
ofstream fout;