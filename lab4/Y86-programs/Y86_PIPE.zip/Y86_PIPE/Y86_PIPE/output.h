#pragma once

#include "output.h"

void table();