#include <iostream>
#include "struct.h"
#include "global_variable.h"
#include "E_stage.h"
#include "convert.h"

using namespace std;

void ALU()
{
	char buffer[LENGTH + 10];
	e_do.clear();
	
	//input: alu.A, alu.B, alu.fun
	//update: CC, valE
	switch (alu.fun)
	{
	case FADDL:
		e.valE = alu.B + alu.A;
		alu.OF = (alu.B < 0 == alu.A < 0) && (e.valE < 0 != alu.B < 0);
		sprintf(buffer, "valE <- %d + %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FSUBL:
		e.valE = alu.B - alu.A;
		alu.OF = (alu.B < 0 == (-alu.A) < 0) && (e.valE < 0 != alu.B < 0);
		sprintf(buffer, "valE <- %d - %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FANDL:
		e.valE = alu.B & alu.A;
		alu.OF = 0;
		sprintf(buffer, "valE <- %d & %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FXORL:
		e.valE = alu.B ^ alu.A;
		alu.OF = 0;
		sprintf(buffer, "valE <- %d ^ %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);	
		break;
	default:
		break;
	}
	alu.SF = e.valE < 0;
	alu.ZF = e.valE == 0;
}

void E_value_update()
{
	if (E.bubble)
	{
		E.stat = SBUB;
		E.icode = INOP;
		E.ifun = FNONE;
		E.valC = 0;
		E.valA = 0;
		E.valB = 0;
		E.dstE = RNONE;
		E.dstM = RNONE;
		E.srcA = RNONE;
		E.srcB = RNONE;
	}
	else
		if (E.stall)
			;
		else
		{
			E.stat = d.stat;
			E.icode = d.icode;
			E.ifun = d.ifun;
			E.valC = d.valC;
			E.valA = d.valA;
			E.valB = d.valB;
			E.dstE = d.dstE;
			E.dstM = d.dstM;
			E.srcA = d.srcA;
			E.srcB = d.srcB;
		}
}

void E_logic_update()
{
	e.stat = E.stat;
	e.icode = E.icode;
	e.dstM = E.dstM;
	e.valA = E.valA;

	//alu.A
	switch (E.icode)
	{
	case IRRMOVL:case IOPL:
		alu.A = E.valA; break;
	case IIRMOVL:case IRMMOVL:case IMRMOVL:case IIADDL:
		alu.A = E.valC; break;
	case ICALL:case IPUSHL:
		alu.A = -4; break;
	case IRET:case IPOPL:case ILEAVE:
		alu.A = 4; break;
	default:
		alu.A = 0; break;
	}

	//alu.B
	switch (E.icode)
	{
	case IMRMOVL:case IRMMOVL:case IOPL:case ICALL:case IPUSHL:case IRET:case IPOPL:case IIADDL:case ILEAVE:
		alu.B = E.valB; break;
	case IRRMOVL:case IIRMOVL:
		alu.B = 0; break;
	default:
		alu.B = 0; break;
	}

	//alu.fun
	switch (E.icode)
	{
	case IOPL:
		alu.fun = E.ifun; break;
	default:
		alu.fun = ALUADD; break;
	}

	//ALU operation
	ALU();

	//input: CC(ZF,SF,OF), E.ifun
	//output: e.Cnd(if predict error, set it 0)
	switch (E.ifun)
	{
	case FJMP:
		e.Cnd = 1; break;
	case FJLE:
		e.Cnd = (CC.SF^CC.OF) | CC.ZF; break;
	case FJL:
		e.Cnd = CC.SF^CC.OF; break;
	case FJE:
		e.Cnd = CC.ZF; break;
	case FJNE:
		e.Cnd = !CC.ZF; break;
	case FJGE:
		e.Cnd = !(CC.SF^CC.OF); break;
	case FJG:
		e.Cnd = !(CC.SF^CC.OF)&(!CC.ZF); break;
	default:
		e.Cnd = 1; break;//normal, e.Cnd should be 1
	}

	//Set dstE to RNONE in event of not-taken conditional move
	if (E.icode == IRRMOVL && !e.Cnd)
		e.dstE = RNONE;
	else
		e.dstE = E.dstE;

	//Should the condition codes be updated?
	//Set CC: a sequential update, update CC at the end of the stage
	CC.set = 
		(E.icode == IOPL || E.icode == IIADDL) &&
		(m.stat != SADR && m.stat != SINS && m.stat != SHLT) &&
		(W.stat != SADR && W.stat != SINS && W.stat != SHLT);
}

void E_stage()
{
	E_value_update();
	E_logic_update();
}