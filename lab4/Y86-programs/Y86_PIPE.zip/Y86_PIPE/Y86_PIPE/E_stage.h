#pragma once

void ALU();
void E_value_update();
void E_logic_update();
void E_stage();