#include <iostream>
#include <string>
#include <Windows.h>
#include <process.h>
#include "pipeline.h"
#include "macro.h"
#include "global_variable.h"
#include "struct.h"
#include "convert.h"
#include "F_stage.h"
#include "D_stage.h"
#include "E_stage.h"
#include "M_stage.h"
#include "W_stage.h"
#include "simulator.h"
#include "output.h"

using namespace std;

void initialize()
{
	//F
	F.bubble = false;
	F.predPC = 0;
	F.stall = false;

	//f
	f.icode = INOP;
	f.ifun = FNONE;
	f.pc = 0;
	f.predPC = 0;
	f.rA = RNONE;
	f.rB = RNONE;
	f.stat = SAOK;
	f.valC = 0;
	f.valP = 0;

	//D
	D.bubble = false;
	D.icode = INOP;
	D.ifun = FNONE;
	D.rA = RNONE;
	D.rB = RNONE;
	D.stall = false;
	D.stat = SAOK;
	D.valC = 0;
	D.valP = 0;

	//d
	d.dstE = RNONE;
	d.dstM = RNONE;
	d.icode = INOP;
	d.ifun = FNONE;
	d.rvalA = 0;
	d.rvalB = 0;
	d.srcA = RNONE;
	d.srcB = RNONE;
	d.stat = SAOK;
	d.valA = 0;
	d.valB = 0;
	d.valC = 0;

	//E
	E.bubble = false;
	E.dstE = RNONE;
	E.dstM = RNONE;
	E.icode = INOP;
	E.ifun = FNONE;
	E.srcA = RNONE;
	E.srcB = RNONE;
	E.stall = false;
	E.stat = SAOK;
	E.valA = 0;
	E.valB = 0;
	E.valC = 0;

	//e
	e.Cnd = 1;
	e.dstE = RNONE;
	e.dstM = RNONE;
	e.icode = INOP;
	e.stat = SAOK;
	e.valA = 0;
	e.valE = 0;
	
	//M
	M.bubble = false;
	M.Cnd = 1;
	M.dstE = RNONE;
	M.dstM = RNONE;
	M.icode = INOP;
	M.ifun = FNONE;
	M.stall = false;
	M.stat = SAOK;
	M.valA = 0;
	M.valE = 0;

	//m
	m.dstE = RNONE;
	m.dstM = RNONE;
	m.icode = INOP;
	m.stat = SAOK;
	m.valE = 0;
	m.valM = 0;

	//W
	W.bubble = false;
	W.dstE = RNONE;
	W.dstM = RNONE;
	W.icode = INOP;
	W.stall = false;
	W.stat = SAOK;
	W.valE = 0;
	W.valM = 0;

	//imem
	imem.error = 0;
	imem.icode = INOP;
	imem.ifun = FNONE;

	//instr
	instr.valid = 0;

	//need
	need.regids = 0;
	need.valC = 0;

	//Stat
	Stat = SAOK;

	//alu
	alu.A = 0;
	alu.B = 0;
	alu.fun = ALUADD;
	alu.OF = 0;
	alu.SF = 0;
	alu.ZF = 0;
	
	//CC
	CC.OF = 0;
	CC.SF = 0;
	CC.ZF = 0;
	CC.set = 0;

	//dmem
	dmem.error = 0;

	//mem
	mem.addr = 0;
	mem.read = 0;
	mem.write = 0;

	//register file
	for (int i = 0; i < 16; i++)
		reg[i] = 0;

	//memory
	for (int i = 0; i < MEMORY_SIZE; i++)
		memory[i] = 0;

	//other variables
	PC = 0;
	error = 0;//abnormal exit
	ins = 0;
	CPI = 0;
	cycle = 0;

	//move
	seq_do.clear();
	m_do.clear();
	e_do.clear();
	d_do.clear();
	f_do.clear();
	//changed memory
	changed.clear();
}

void control_update()
{
//F
	//bubble or stall
	F.bubble = 0;//not exist
	F.stall = (E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) && (E.dstM == d.srcA || E.dstM == d.srcB) || (IRET == D.icode || IRET == E.icode || IRET == M.icode);

//D
	//Mispredicted branch					Stalling at fetch while ret passes through pipeline, but not condition for a load / use hazard
	D.bubble = (E.icode == IJXX && !e.Cnd) ||
		!((E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) && (E.dstM == d.srcA || E.dstM == d.srcB)) &&
			(IRET == D.icode || IRET == E.icode || IRET == M.icode);

	//Conditions for a load/use hazard
	D.stall = (E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) && 
		(E.dstM == d.srcA || E.dstM == d.srcB);

//E
	E.stall = 0;
	E.bubble = (E.icode == IJXX && !e.Cnd) ||
		(E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) &&
		(E.dstM == d.srcA || E.dstM == d.srcB);

//M
	M.bubble = (m.stat == SADR || m.stat == SINS || m.stat == SHLT) ||
		(W.stat == SADR || W.stat == SINS || W.stat == SHLT);
	M.stall = 0;

//W
	W.stall = W.stat == SADR || W.stat == SINS || W.stat == SHLT;
	W.bubble = 0;
}

void sequential_update()
{
	string s;
	char buffer[LENGTH + 10];
	seq_do.clear();

	//dmemory
	if (!dmem.error && M.stat!=SBUB && mem.write)
	{
		//data update
		write_int(mem.addr, M.valA);//sequential: write memory at the end of the stage
		m.valM = 0;//if it's write memory, there is no need to get data from memor, so make it NULL

		//sequential update section
		sprintf(buffer, "M4[0x%x] <- %d", mem.addr, M.valA);
		seq_do.push_back(buffer);

		//changed memory section
		changed[mem.addr] = M.valA;
	}

	//CC
	if (CC.set)
	{
		//CC update
		CC.OF = alu.OF;
		CC.SF = alu.SF;
		CC.ZF = alu.ZF;

		//sequential update section
		sprintf(buffer, "ZF <- %-11d  SF <- %-11d  OF <- %-11d ", CC.ZF, CC.SF, CC.OF);
		seq_do.push_back(buffer);
	}

	//register file (sequential, write register at the end of the stage)
	if (W.stat == SAOK || W.stat == SBUB)
	{
		if (W.dstE != RNONE)//reg[W.dstE]
		{
			reg[W.dstE] = W.valE;
			s = "R[" + get_reg(W.dstE) + "] <- ";
			sprintf(buffer, "%d", W.valE);
			s += buffer;
			seq_do.push_back(s);
		}

		if (W.dstM != RNONE)//reg[W.dstM]
		{
			reg[W.dstM] = W.valM;
			s = "R[" + get_reg(W.dstM) + "] <- ";
			sprintf(buffer, "%d", W.valM);
			s += buffer;
			seq_do.push_back(s);
		}
	}
}

void posedge_edge_clock()
{
	//cycle count
	cycle++;

	//update sequential components: CC, memory, reg files
	sequential_update();

	//5 stages
	W_stage();
	M_stage();
	E_stage();
	D_stage();
	F_stage();

	//update every stage's need of bubble or stall for the next coming stage
	control_update();

	//print reg file, CC, PC, and every stage's registers
	table();
}

void run()
{
	while (1)
	{
		Sleep(8000 - speed);
		posedge_edge_clock();
		if (error)
		{
			error = 0;
			return;
		}
	}
}