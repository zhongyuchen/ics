#include <iostream>
#include "all.h"

using namespace std;

int main()
{
	simulator();
}