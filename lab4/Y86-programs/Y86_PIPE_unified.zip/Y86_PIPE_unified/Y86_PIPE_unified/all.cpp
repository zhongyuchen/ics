#include "all.h"

//structures
struct F_register F = F_register();
struct f_value f = f_value();
struct need_value need = need_value();
struct instr_value instr = instr_value();
struct imem_value imem = imem_value();
struct D_register D = D_register();
struct d_value d = d_value();
struct E_register E = E_register();
struct e_value e = e_value();
struct alu_logic alu = alu_logic();
struct CC_register CC = CC_register();
struct M_register M = M_register();
struct dmem_value dmem = dmem_value();
struct mem_value mem = mem_value();
struct m_value m = m_value();
struct W_register W = W_register();

int PC;
//clock cycle
int cycle;
//abnormal exit
bool error;
//Stat: the actual state of the process
int Stat;
int input;
int ins;
double CPI;
int speed;
int output;
int save;

//memory
int memory[MEMORY_SIZE];
//register file
int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

			//move
vector<string> seq_do;
vector<string> m_do;
vector<string> e_do;
vector<string> d_do;
vector<string> f_do;
//changed memory
map<int, int> changed;

//file output
ofstream fout;

int char_to_int(char c)
{
	if (c >= '0'&&c <= '9')
		return c - '0';
	if (c >= 'a'&&c <= 'f')
		return c - 'a' + 10;
	if (c >= 'A'&&c <= 'F')
		return c - 'A' + 10;
	return 0;
}

string get_reg(int reg_fun)
{
	switch (reg_fun)
	{
	case EAX: return "%eax";
	case ECX: return "%ecx";
	case EDX: return "%edx";
	case EBX: return "%ebx";
	case ESP: return "%esp";
	case EBP: return "%ebp";
	case ESI: return "%esi";
	case EDI: return "%edi";
	case E8: return "%e8";
	case E9: return "%e9";
	case E10: return "%e10";
	case E11: return "%e11";
	case E12: return "%e12";
	case E13: return "%e13";
	case E14: return "%e14";
	case ENONE: return "ENONE";//not exist
	default: return "ERROR";
	}
}

string get_icode(int icode)
{
	switch (icode)
	{
	case IHALT:return "IHALT";
	case INOP:return "INOP";
	case IRRMOVL:return "IRRMOVL";
	case IIRMOVL:return "IIRMOVL";
	case IRMMOVL:return "IRMMOVL";
	case IMRMOVL:return "IMRMOVL";
	case IOPL:return "IOPL";
	case IJXX:return "IJXX";
	case ICALL:return "ICALL";
	case IRET:return "IRET";
	case IPUSHL:return "IPUSHL";
	case IPOPL:return "IPOPL";
	case IIADDL:return "IIADDL";
	case ILEAVE:return "ILEAVE";
	default:return "ERROR";
	}
}

string get_ifun(int icode, int ifun)
{
	//1.icode IOPL
	if (icode == IOPL)
	{
		switch (ifun)
		{
		case FADDL:return "FADDL";
		case FSUBL:return "FSUBL";
		case FANDL:return "FANDL";
		case FXORL:return "FXORL";
		default:return "ERROR";
		}
	}

	//2.icode IJXX or IRRMOVL
	if (icode == IJXX || icode == IRRMOVL)
	{
		switch (ifun)
		{
		case FJMP:return "FJMP";
		case FJLE:return "FJLE";
		case FJL:return "FJL";
		case FJE:return "FJE";
		case FJNE:return "FJNE";
		case FJGE:return "FJGE";
		case FJG:return "FJG";
		default:return "ERROR";
		}
	}

	//3.icode default
	switch (ifun)
	{
	case FNONE:return "FNONE";
	default:return "ERROR";
	}
}

string get_stat(int stat)
{
	switch (stat)
	{
	case SBUB:return "SBUB";//bubble
	case SAOK:return "SAOK";//normal
	case SADR:return "SADR";//address abnormal
	case SINS:return "SINS";//instruction abnormal
	case SHLT:return "SHLT";//halt
	default:return "ERROR";
	}
}

void simulator()
{
	int i;
	char filename[100];
	FILE *fp;
	string s;

	//title
	BLUE;
	printf("Y86 Pipeline@Zhongyu Chen\n");
	printf("Serial number 16307130194\n");
	GREEN;
	printf("Starting...\n");
	CYAN;
	printf("Features\n");
	printf("1.Storing: Little Endian\n");
	printf("2.Architecture: Von Neumann\n");
	printf("3.Width: 32 bits\n");
	printf("4.ROM: 134,217,728 B\n");
	printf("5.Instructions: halt, nop, rrmovl, irmovl, rmmovl, mrmovl, cmovxx, opl, jxx, call, ret, push, pop, push\n");
	GREEN;
	printf("Successful!\n");

	//run UI
	while (1)
	{
		initialize();

		//exit
		YELLOW;
		printf("Do you want to exit or continue?(default as 0)\n");
		printf("0.continue\n");
		printf("1.exit\n");
		WHITE;
		cin.clear();
		cin >> i;
		if (i)
			break;

		GREEN;
		printf("Continuing...\n");

		//begin
		BLUE;
		printf("Please follow the instructions and input the number of the operation!\n");

		//input mode
		YELLOW;
		printf("Choose input mode(default as 0)\n");
		printf("0.input .yo file\n");
		printf("1.input binary file\n");
		printf("2.input hexadecimal file\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:input = YO; break;
		case 1:input = BIN; break;
		case 2:input = HEX; break;
		default:input = YO; break;
		}

		//output mode
		YELLOW;
		printf("Choose output mode(default as 0)\n");
		printf("0.rolling mode\n");
		printf("1.still mode(this mode can only run program once)\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:output = ROL; break;
		case 1:output = STI; break;
		default:output = 0;
		}

		//speed
		YELLOW;
		printf("Input speed of running programs(0~8000, slow to fast)\n");
		WHITE;
		cin >> speed;
		if (speed < 0)
			speed = 0;
		else
			if (speed > 8000)
				speed = 8000;

		//save file?
		YELLOW;
		printf("Do you want to save as output.txt?(default as 0)\n");
		printf("0.view only\n");
		printf("1.save as well\n");
		WHITE;
		cin >> i;
		switch (i)
		{
		case 0:save = SEE; break;
		case 1:save = SAV; break;
		default:save = SEE;
		}

		//input file
		YELLOW;
		printf("Input the route of the file\n");
		WHITE;
		cin.clear();
		cin >> filename;
		if ((fp = fopen(filename, "rb")) == NULL)
		{
			RED;
			printf("%s: No such file or directory\n", filename);
			cin.clear();
			continue;
		}
		else
		{
			freopen(filename, "rb", stdin);
			switch (input)
			{
			case YO:yo_input(); break;
			case BIN:binary_input(); break;
			case HEX:hex_input(); break;
			}
			fclose(fp);

			GREEN;
			printf("Successful!\n");
		}

		//print the head
		if (save == SAV)
		{
			for (i = 0, s = ""; filename[i] != '.'; i++)
				s += filename[i];
			s += "-output.txt";
			fout.open(s.c_str());
			fout << "-----------------------------------------------------------" << endl;
			fout << "Running program in " << filename << endl;
			fout << "-----------------------------------------------------------" << endl;
			fout << endl << endl << endl;
		}

		//click to run
		YELLOW;
		printf("Type in any char to run\n");
		freopen("CON", "r", stdin);
		char c = getchar();

		//running
		WHITE;
		run();

		//ended
		GREEN;
		printf("Program ended!\n");
		cin.clear();

		//close the output progress to file
		if (output == SAV)
			fout.close();

		WHITE;
	}

	GREEN;
	printf("Y86 Pipeline Processor has ended!\n");
	WHITE;
}

void hex_input()
{
	char c;
	int length = 0;
	while (cin >> c)
	{
		if (c >= '0'&&c <= '9' || c >= 'a'&&c <= 'f' || c >= 'A'&&c <= 'F')
			memory[length++] = char_to_int(c);
	}
}

void binary_input()
{
	char c;
	int i, k, length = 0;
	do
	{
		for (i = 0, k = 0; i < 4 && (c = getchar()); i++)
			k = k * 2 + c - '0';
		if (c != EOF)
			memory[length++] = k;
	} while (c != EOF);
}

void yo_input()
{
	char c;
	string line;
	int length = 0, i;
	int line_size;

	while (getline(cin, line))
	{
		line_size = line.size();
		for (i = 0; i < line_size && line[i] != ':' && line[i] != '|'; i++)
			;
		for (; i < line_size && line[i] != '|'; i++)
		{
			c = line[i];
			if (c >= '0'&&c <= '9' || c >= 'a'&&c <= 'f' || c >= 'A'&&c <= 'F')
				memory[length++] = char_to_int(c);
		}
	}
}

void initialize()
{
	//F
	F.bubble = false;
	F.predPC = 0;
	F.stall = false;

	//f
	f.icode = INOP;
	f.ifun = FNONE;
	f.pc = 0;
	f.predPC = 0;
	f.rA = RNONE;
	f.rB = RNONE;
	f.stat = SAOK;
	f.valC = 0;
	f.valP = 0;

	//D
	D.bubble = false;
	D.icode = INOP;
	D.ifun = FNONE;
	D.rA = RNONE;
	D.rB = RNONE;
	D.stall = false;
	D.stat = SAOK;
	D.valC = 0;
	D.valP = 0;

	//d
	d.dstE = RNONE;
	d.dstM = RNONE;
	d.icode = INOP;
	d.ifun = FNONE;
	d.rvalA = 0;
	d.rvalB = 0;
	d.srcA = RNONE;
	d.srcB = RNONE;
	d.stat = SAOK;
	d.valA = 0;
	d.valB = 0;
	d.valC = 0;

	//E
	E.bubble = false;
	E.dstE = RNONE;
	E.dstM = RNONE;
	E.icode = INOP;
	E.ifun = FNONE;
	E.srcA = RNONE;
	E.srcB = RNONE;
	E.stall = false;
	E.stat = SAOK;
	E.valA = 0;
	E.valB = 0;
	E.valC = 0;

	//e
	e.Cnd = 1;
	e.dstE = RNONE;
	e.dstM = RNONE;
	e.icode = INOP;
	e.stat = SAOK;
	e.valA = 0;
	e.valE = 0;

	//M
	M.bubble = false;
	M.Cnd = 1;
	M.dstE = RNONE;
	M.dstM = RNONE;
	M.icode = INOP;
	M.ifun = FNONE;
	M.stall = false;
	M.stat = SAOK;
	M.valA = 0;
	M.valE = 0;

	//m
	m.dstE = RNONE;
	m.dstM = RNONE;
	m.icode = INOP;
	m.stat = SAOK;
	m.valE = 0;
	m.valM = 0;

	//W
	W.bubble = false;
	W.dstE = RNONE;
	W.dstM = RNONE;
	W.icode = INOP;
	W.stall = false;
	W.stat = SAOK;
	W.valE = 0;
	W.valM = 0;

	//imem
	imem.error = 0;
	imem.icode = INOP;
	imem.ifun = FNONE;

	//instr
	instr.valid = 0;

	//need
	need.regids = 0;
	need.valC = 0;

	//Stat
	Stat = SAOK;

	//alu
	alu.A = 0;
	alu.B = 0;
	alu.fun = ALUADD;
	alu.OF = 0;
	alu.SF = 0;
	alu.ZF = 0;

	//CC
	CC.OF = 0;
	CC.SF = 0;
	CC.ZF = 0;
	CC.set = 0;

	//dmem
	dmem.error = 0;

	//mem
	mem.addr = 0;
	mem.read = 0;
	mem.write = 0;

	//register file
	for (int i = 0; i < 16; i++)
		reg[i] = 0;

	//memory
	for (int i = 0; i < MEMORY_SIZE; i++)
		memory[i] = 0;

	//other variables
	PC = 0;
	error = 0;//abnormal exit
	ins = 0;
	CPI = 0;
	cycle = 0;

	//move
	seq_do.clear();
	m_do.clear();
	e_do.clear();
	d_do.clear();
	f_do.clear();
	//changed memory
	changed.clear();
}

void control_update()
{
	//F
	//bubble or stall
	F.bubble = 0;//not exist
	F.stall = (E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) && (E.dstM == d.srcA || E.dstM == d.srcB) || (IRET == D.icode || IRET == E.icode || IRET == M.icode);

	//D
	//Mispredicted branch					Stalling at fetch while ret passes through pipeline, but not condition for a load / use hazard
	D.bubble = (E.icode == IJXX && !e.Cnd) ||
		!((E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) && (E.dstM == d.srcA || E.dstM == d.srcB)) &&
		(IRET == D.icode || IRET == E.icode || IRET == M.icode);

	//Conditions for a load/use hazard
	D.stall = (E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) &&
		(E.dstM == d.srcA || E.dstM == d.srcB);

	//E
	E.stall = 0;
	E.bubble = (E.icode == IJXX && !e.Cnd) ||
		(E.icode == IMRMOVL || E.icode == IPOPL || E.icode == ILEAVE) &&
		(E.dstM == d.srcA || E.dstM == d.srcB);

	//M
	M.bubble = (m.stat == SADR || m.stat == SINS || m.stat == SHLT) ||
		(W.stat == SADR || W.stat == SINS || W.stat == SHLT);
	M.stall = 0;

	//W
	W.stall = W.stat == SADR || W.stat == SINS || W.stat == SHLT;
	W.bubble = 0;
}

void sequential_update()
{
	string s;
	char buffer[LENGTH + 10];
	seq_do.clear();

	//dmemory
	if (!dmem.error && M.stat != SBUB && mem.write)
	{
		//data update
		write_int(mem.addr, M.valA);//sequential: write memory at the end of the stage
		m.valM = 0;//if it's write memory, there is no need to get data from memor, so make it NULL

				   //sequential update section
		sprintf(buffer, "M4[0x%x] <- %d", mem.addr, M.valA);
		seq_do.push_back(buffer);

		//changed memory section
		changed[mem.addr] = M.valA;
	}

	//CC
	if (CC.set)
	{
		//CC update
		CC.OF = alu.OF;
		CC.SF = alu.SF;
		CC.ZF = alu.ZF;

		//sequential update section
		sprintf(buffer, "ZF <- %-11d  SF <- %-11d  OF <- %-11d ", CC.ZF, CC.SF, CC.OF);
		seq_do.push_back(buffer);
	}

	//register file (sequential, write register at the end of the stage)
	if (W.stat == SAOK || W.stat == SBUB)
	{
		if (W.dstE != RNONE)//reg[W.dstE]
		{
			reg[W.dstE] = W.valE;
			s = "R[" + get_reg(W.dstE) + "] <- ";
			sprintf(buffer, "%d", W.valE);
			s += buffer;
			seq_do.push_back(s);
		}

		if (W.dstM != RNONE)//reg[W.dstM]
		{
			reg[W.dstM] = W.valM;
			s = "R[" + get_reg(W.dstM) + "] <- ";
			sprintf(buffer, "%d", W.valM);
			s += buffer;
			seq_do.push_back(s);
		}
	}
}

void posedge_edge_clock()
{
	//cycle count
	cycle++;

	//update sequential components: CC, memory, reg files
	sequential_update();

	//5 stages
	W_stage();
	M_stage();
	E_stage();
	D_stage();
	F_stage();

	//update every stage's need of bubble or stall for the next coming stage
	control_update();

	//print reg file, CC, PC, and every stage's registers
	table();
}

void run()
{
	while (1)
	{
		Sleep(8000 - speed);
		posedge_edge_clock();
		if (error)
		{
			error = 0;
			return;
		}
	}
}

void F_value_update()
{
	if (F.bubble)
		;//F stage can't be bubbled anyway
	else
		if (F.stall)//no change
			;
		else
			F.predPC = f.predPC;
}

void F_logic_update()
{
	char buffer[LENGTH + 10];
	f_do.clear();

	//f.pc: What address should instruction be fetched at
	if (M.icode == IJXX && M.Cnd == 0)//predict error!
	{
		f.pc = M.valA;
		sprintf(buffer, "f.pc <- M.valA = 0x%x", M.valA);
		f_do.push_back(buffer);
	}
	else
		if (W.icode == IRET)
		{
			f.pc = W.valM;
			sprintf(buffer, "f.pc <- W.valM = 0x%x", W.valM);
			f_do.push_back(buffer);
		}
		else
		{
			f.pc = F.predPC;
			sprintf(buffer, "f.pc <- F.predPC = 0x%x", F.predPC);
			f_do.push_back(buffer);
		}

	//use PC to read memory for instruction codes
	imem.error = check_segmentation(f.pc + 12);
	if (!imem.error)
	{
		imem.icode = memory[f.pc * 2];
		imem.ifun = memory[f.pc * 2 + 1];
	}

	//f.icode: Determine icode of fetched instruction
	//f.ifun: determin ifun
	if (imem.error)
		f.icode = INOP, f.ifun = FNONE;
	else
		f.icode = imem.icode, f.ifun = imem.ifun;

	//fetch icode & ifun
	sprintf(buffer, "icode:ifun <- M1[0x%x] = %x:%x = ", f.pc, f.icode, f.ifun);
	f_do.push_back(buffer + get_icode(f.icode) + ":" + get_ifun(f.icode, f.ifun));

	//Is instruction valid?
	instr.valid =
		f.icode == INOP && f.ifun == FNONE ||
		f.icode == IHALT && f.ifun == FNONE ||
		f.icode == IRRMOVL && f.ifun >= FJMP && f.ifun <= FJG ||
		f.icode == IIRMOVL && f.ifun == FNONE ||
		f.icode == IRMMOVL && f.ifun == FNONE ||
		f.icode == IMRMOVL && f.ifun == FNONE ||
		f.icode == IOPL && f.ifun <= FXORL && f.ifun >= FADDL ||
		f.icode == IJXX && f.ifun <= FJG && f.ifun >= FJMP ||
		f.icode == ICALL && f.ifun == FNONE ||
		f.icode == IRET && f.ifun == FNONE ||
		f.icode == IPUSHL && f.ifun == FNONE ||
		f.icode == IPOPL && f.ifun == FNONE ||
		f.icode == IIADDL && f.ifun == FNONE ||
		f.icode == ILEAVE && f.ifun == FNONE;

	//Determine status code for fetched instruction
	if (imem.error)
		f.stat = SADR;
	else
		if (!instr.valid)
			f.stat = SINS;
		else
			if (f.icode == IHALT)
				f.stat = SHLT;
			else
				f.stat = SAOK;//normal

							  //Does fetched instruction require a reg-id byte?
	need.regids =
		f.icode == IRRMOVL ||
		f.icode == IOPL ||
		f.icode == IPUSHL ||
		f.icode == IPOPL ||
		f.icode == IIRMOVL ||
		f.icode == IRMMOVL ||
		f.icode == IMRMOVL ||
		f.icode == IIADDL;

	if (need.regids)
	{
		f.rA = memory[f.pc * 2 + 2];
		f.rB = memory[f.pc * 2 + 3];
		sprintf(buffer, "rA:rB <- M1[0x%x] = %x:%x = ", f.pc + 1, f.rA, f.rB);
		f_do.push_back(buffer + get_reg(f.rA) + ":" + get_reg(f.rB));
	}
	else
	{
		f.rA = f.rB = RNONE;
		f_do.push_back("rA:rB <- f:f = ENONE:ENONE");
	}

	//Does fetched instruction require a constant word?
	need.valC =
		f.icode == IIRMOVL ||
		f.icode == IRMMOVL ||
		f.icode == IMRMOVL ||
		f.icode == IJXX ||
		f.icode == ICALL ||
		f.icode == IIADDL;

	if (need.valC)
		if (need.regids)
		{
			f.valC = get_int(f.pc + 2);
			sprintf(buffer, "valC <- M4[0x%x] = %d", f.pc + 2, f.valC);
			f_do.push_back(buffer);
		}
		else
		{
			f.valC = get_int(f.pc + 1);
			sprintf(buffer, "valC <- M4[0x%x] = %d", f.pc + 1, f.valC);
			f_do.push_back(buffer);
		}

	//f.valP
	f.valP = f.pc + 1 + need.regids * 1 + need.valC * 4;
	sprintf(buffer, "valP <- 0x%x + %d = 0x%x", f.pc, 1 + need.regids * 1 + need.valC * 4, f.valP);
	f_do.push_back(buffer);

	//Predict next value of PC
	if (f.icode == IJXX || f.icode == ICALL)
		f.predPC = f.valC;
	else
		f.predPC = f.valP;
}

void F_stage()
{
	F_value_update();
	F_logic_update();
}

void D_value_update()//the data from F goes in D register
{
	if (D.bubble)
	{
		D.stat = SBUB;
		D.icode = INOP;
		D.ifun = FNONE;
		D.rA = RNONE;
		D.rB = RNONE;
		D.valC = 0;
		D.valP = 0;
	}
	else
		if (D.stall)//stall: keep the value not changed
			;
		else//pass on the values from f
		{
			D.stat = f.stat;
			D.icode = f.icode;
			D.ifun = f.ifun;
			D.rA = f.rA;
			D.rB = f.rB;
			D.valC = f.valC;
			D.valP = f.valP;
		}
}

void D_logic_update()
{
	char buffer[LENGTH + 10];
	d_do.clear();

	d.stat = D.stat;
	d.icode = D.icode;
	d.ifun = D.ifun;
	d.valC = D.valC;

	//d.srcA
	switch (D.icode)
	{
	case IRRMOVL:case IRMMOVL:case IOPL:case IPUSHL:case IIADDL:
		d.srcA = D.rA; break;
	case IPOPL:case IRET:
		d.srcA = RRSP; break;
	case ILEAVE:
		d.srcA = EBP; break;
	default:
		d.srcA = RNONE; break;
	}

	//d.srcB
	switch (D.icode)
	{
	case IOPL:case IRMMOVL:case IMRMOVL:case IIADDL:
		d.srcB = D.rB; break;
	case IPUSHL:case IPOPL:case ICALL:case IRET:
		d.srcB = RRSP; break;
	case ILEAVE:
		d.srcB = EBP; break;
	default:
		d.srcB = RNONE; break;
	}

	//d.dstE
	switch (D.icode)
	{
	case IRRMOVL:case IIRMOVL:case IOPL:case IIADDL:
		d.dstE = D.rB; break;
	case IPUSHL:case IPOPL:case ICALL:case IRET:case ILEAVE:
		d.dstE = RRSP; break;
	default:
		d.dstE = RNONE; break;
	}

	//d.dstM
	switch (D.icode)
	{
	case IMRMOVL:case IPOPL:
		d.dstM = D.rA; break;
	case ILEAVE:
		d.dstM = EBP; break;
	default:
		d.dstM = RNONE; break;
	}

	//d.rvalA, d.rvalB
	d.rvalA = reg[d.srcA];
	d.rvalB = reg[d.srcB];

	//d.valA (Forward into decode stage for valA)
	if (D.icode == ICALL || D.icode == IJXX)//Use incremented PC
	{
		d.valA = D.valP;
		sprintf(buffer, "valA <- D.valP = %d", D.valP);
		d_do.push_back(buffer);
	}
	else
		if (d.srcA == e.dstE)//forward valE from execute
		{
			d.valA = e.valE;
			sprintf(buffer, "valA <- e.valE = %d", e.valE);
			d_do.push_back(buffer);
		}
		else
			if (d.srcA == M.dstM)//forward valM from memory
			{
				d.valA = m.valM;
				sprintf(buffer, "valA <- m.valM = %d", m.valM);
				d_do.push_back(buffer);
			}
			else
				if (d.srcA == M.dstE)//Forward valE from memory
				{
					d.valA = M.valE;
					sprintf(buffer, "valA <- M.valE = %d", M.valE);
					d_do.push_back(buffer);
				}
				else
					if (d.srcA == W.dstM)//Forward valM from write back
					{
						d.valA = W.valM;
						sprintf(buffer, "valA <- W.valM = %d", W.valM);
						d_do.push_back(buffer);
					}
					else
						if (d.srcA == W.dstE)//Forward valE from write back
						{
							d.valA = W.valE;
							sprintf(buffer, "valA <- W.valE = %d", W.valE);
							d_do.push_back(buffer);
						}
						else//Use value read from register file
						{
							d.valA = d.rvalA;
							sprintf(buffer, "%d", reg[d.srcA]);
							d_do.push_back("valA <- R[" + get_reg(d.srcA) + "] = " + buffer);
						}

	//d.valB
	if (d.srcB == e.dstE)//Forward valE from execute
	{
		d.valB = e.valE;
		sprintf(buffer, "valB <- e.valE = %d", e.valE);
		d_do.push_back(buffer);
	}
	else
		if (d.srcB == M.dstM)//Forward valM from memory
		{
			d.valB = m.valM;
			sprintf(buffer, "valB <- m.valM = %d", m.valM);
			d_do.push_back(buffer);
		}
		else
			if (d.srcB == M.dstE)//Forward valE from memory
			{
				d.valB = M.valE;
				sprintf(buffer, "valB <- M.valE = %d", M.valE);
				d_do.push_back(buffer);
			}
			else
				if (d.srcB == W.dstM)//Forward valM from write back
				{
					d.valB = W.valM;
					sprintf(buffer, "valB <- W.valM = %d", W.valM);
					d_do.push_back(buffer);
				}
				else
					if (d.srcB == W.dstE)//Forward valE from write back
					{
						d.valB = W.valE;
						sprintf(buffer, "valB <- W.valE = %d", W.valE);
						d_do.push_back(buffer);
					}
					else//Use value read from register file
					{
						d.valB = d.rvalB;
						sprintf(buffer, "%d", reg[d.srcB]);
						d_do.push_back("valB <- R[" + get_reg(d.srcB) + "] = " + buffer);
					}
}

void D_stage()
{
	D_value_update();
	D_logic_update();
}

void ALU()
{
	char buffer[LENGTH + 10];
	e_do.clear();

	//input: alu.A, alu.B, alu.fun
	//update: CC, valE
	switch (alu.fun)
	{
	case FADDL:
		e.valE = alu.B + alu.A;
		alu.OF = (alu.B < 0 == alu.A < 0) && (e.valE < 0 != alu.B < 0);
		sprintf(buffer, "valE <- %d + %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FSUBL:
		e.valE = alu.B - alu.A;
		alu.OF = (alu.B < 0 == (-alu.A) < 0) && (e.valE < 0 != alu.B < 0);
		sprintf(buffer, "valE <- %d - %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FANDL:
		e.valE = alu.B & alu.A;
		alu.OF = 0;
		sprintf(buffer, "valE <- %d & %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	case FXORL:
		e.valE = alu.B ^ alu.A;
		alu.OF = 0;
		sprintf(buffer, "valE <- %d ^ %d = %d", alu.B, alu.A, e.valE);
		e_do.push_back(buffer);
		break;
	default:
		break;
	}
	alu.SF = e.valE < 0;
	alu.ZF = e.valE == 0;
}

void E_value_update()
{
	if (E.bubble)
	{
		E.stat = SBUB;
		E.icode = INOP;
		E.ifun = FNONE;
		E.valC = 0;
		E.valA = 0;
		E.valB = 0;
		E.dstE = RNONE;
		E.dstM = RNONE;
		E.srcA = RNONE;
		E.srcB = RNONE;
	}
	else
		if (E.stall)
			;
		else
		{
			E.stat = d.stat;
			E.icode = d.icode;
			E.ifun = d.ifun;
			E.valC = d.valC;
			E.valA = d.valA;
			E.valB = d.valB;
			E.dstE = d.dstE;
			E.dstM = d.dstM;
			E.srcA = d.srcA;
			E.srcB = d.srcB;
		}
}

void E_logic_update()
{
	e.stat = E.stat;
	e.icode = E.icode;
	e.dstM = E.dstM;
	e.valA = E.valA;

	//alu.A
	switch (E.icode)
	{
	case IRRMOVL:case IOPL:
		alu.A = E.valA; break;
	case IIRMOVL:case IRMMOVL:case IMRMOVL:case IIADDL:
		alu.A = E.valC; break;
	case ICALL:case IPUSHL:
		alu.A = -4; break;
	case IRET:case IPOPL:case ILEAVE:
		alu.A = 4; break;
	default:
		alu.A = 0; break;
	}

	//alu.B
	switch (E.icode)
	{
	case IMRMOVL:case IRMMOVL:case IOPL:case ICALL:case IPUSHL:case IRET:case IPOPL:case IIADDL:case ILEAVE:
		alu.B = E.valB; break;
	case IRRMOVL:case IIRMOVL:
		alu.B = 0; break;
	default:
		alu.B = 0; break;
	}

	//alu.fun
	switch (E.icode)
	{
	case IOPL:
		alu.fun = E.ifun; break;
	default:
		alu.fun = ALUADD; break;
	}

	//ALU operation
	ALU();

	//input: CC(ZF,SF,OF), E.ifun
	//output: e.Cnd(if predict error, set it 0)
	switch (E.ifun)
	{
	case FJMP:
		e.Cnd = 1; break;
	case FJLE:
		e.Cnd = (CC.SF^CC.OF) | CC.ZF; break;
	case FJL:
		e.Cnd = CC.SF^CC.OF; break;
	case FJE:
		e.Cnd = CC.ZF; break;
	case FJNE:
		e.Cnd = !CC.ZF; break;
	case FJGE:
		e.Cnd = !(CC.SF^CC.OF); break;
	case FJG:
		e.Cnd = !(CC.SF^CC.OF)&(!CC.ZF); break;
	default:
		e.Cnd = 1; break;//normal, e.Cnd should be 1
	}

	//Set dstE to RNONE in event of not-taken conditional move
	if (E.icode == IRRMOVL && !e.Cnd)
		e.dstE = RNONE;
	else
		e.dstE = E.dstE;

	//Should the condition codes be updated?
	//Set CC: a sequential update, update CC at the end of the stage
	CC.set =
		(E.icode == IOPL || E.icode == IIADDL) &&
		(m.stat != SADR && m.stat != SINS && m.stat != SHLT) &&
		(W.stat != SADR && W.stat != SINS && W.stat != SHLT);
}

void E_stage()
{
	E_value_update();
	E_logic_update();
}

bool check_segmentation(int pc)//input real address
{
	if ((pc + 4) * 2 < MEMORY_SIZE && pc * 2 >= 0)
		return 0;
	return 1;//segmentation
}

//get an integer from instruction memory
int get_int(int address)//input theoretical address
{
	int ret = 0;
	ret ^= (memory[address * 2 + 1] << 0) & 0xf;
	ret ^= (memory[address * 2 + 0] << 4) & 0xf0;
	ret ^= (memory[address * 2 + 3] << 8) & 0xf00;
	ret ^= (memory[address * 2 + 2] << 12) & 0xf000;
	ret ^= (memory[address * 2 + 5] << 16) & 0xf0000;
	ret ^= (memory[address * 2 + 4] << 20) & 0xf00000;
	ret ^= (memory[address * 2 + 7] << 24) & 0xf000000;
	ret ^= (memory[address * 2 + 6] << 28) & 0xf0000000;
	return ret;
}

void M_value_update()
{
	if (M.bubble)
	{
		M.stat = SBUB;
		M.icode = INOP;
		M.Cnd = 1;//normal
		M.valE = 0;
		M.valA = 0;
		M.dstE = RNONE;
		M.dstM = RNONE;
	}
	else
		if (M.stall)
			;
		else
		{
			M.stat = e.stat;
			M.icode = e.icode;
			M.Cnd = e.Cnd;
			M.valE = e.valE;
			M.valA = e.valA;
			M.dstE = e.dstE;
			M.dstM = e.dstM;
		}
}

void M_logic_update()
{
	char buffer[LENGTH + 10];
	m_do.clear();

	//mem.addr
	switch (M.icode)
	{
	case IRMMOVL:case IPUSHL:case ICALL:case IMRMOVL:
		mem.addr = M.valE; break;
	case IPOPL:case IRET:case ILEAVE:
		mem.addr = M.valA; break;
	default:
		break;
	}

	//(either one below can be TRUE)
	//Set read control signal
	mem.read = M.icode == IMRMOVL || M.icode == IPOPL || M.icode == IRET || M.icode == ILEAVE;
	//Set write control signal
	mem.write = M.icode == IRMMOVL || M.icode == IPUSHL || M.icode == ICALL;

	//dmem.error
	if (mem.read || mem.write)
		dmem.error = check_segmentation(mem.addr);
	else
		dmem.error = 0;

	//m.stat
	if (dmem.error)
		m.stat = SADR;
	else
		m.stat = M.stat;

	m.icode = M.icode;
	m.valE = M.valE;
	m.dstE = M.dstE;
	m.dstM = M.dstM;

	//read m.valM in memory with address of mem.addr
	if (!dmem.error&&mem.read)//no data memory error && need to read memory
	{
		m.valM = get_int(mem.addr);
		sprintf(buffer, "valM <- M4[0x%x] = %d", mem.addr, get_int(mem.addr));
		m_do.push_back(buffer);
	}
}

void M_stage()
{
	M_value_update();
	M_logic_update();
}

void write_int(int address, int value)//input theoretical address
{
	memory[address * 2 + 1] = value & 0xf;
	memory[address * 2 + 0] = (value >> 4) & 0xf;
	memory[address * 2 + 3] = (value >> 8) & 0xf;
	memory[address * 2 + 2] = (value >> 12) & 0xf;
	memory[address * 2 + 5] = (value >> 16) & 0xf;
	memory[address * 2 + 4] = (value >> 20) & 0xf;
	memory[address * 2 + 7] = (value >> 24) & 0xf;
	memory[address * 2 + 6] = (value >> 28) & 0xf;
}

void W_value_update()
{
	if (W.bubble)
	{
		W.stat = SBUB;
		W.icode = INOP;
		W.valE = 0;
		W.valM = 0;
		W.dstE = RNONE;
		W.dstM = RNONE;
	}
	else
		if (W.stall)
			;
		else
		{
			W.stat = m.stat;
			W.icode = m.icode;
			W.valE = m.valE;
			W.valM = m.valM;
			W.dstE = m.dstE;
			W.dstM = m.dstM;
		}
}

void W_logic_update()
{
	//Update status of the processor
	if (W.stat == SBUB)
		Stat = SAOK, ins++;
	else
		Stat = W.stat;

	//exit or not?
	switch (Stat)
	{
	case SAOK:
		break;
	case SADR:case SINS:case SHLT:
		error = 1; break;
	}
}

void W_stage()
{
	W_value_update();
	W_logic_update();
}

//name length: 6
//between name and value: 1
//value length: 11
//between value and next length: 1
void table()
{
	//variables
	int i;
	int p = 0;//pointer
	int need;
	int size;
	const int length = LENGTH - 1;
	string s[OUTPUT_SIZE];
	string temp;
	char buffer[LENGTH + 10];

	//1.cycle line
	need = sprintf(buffer, "CYCLE %d", cycle);
	s[p] = "-----------------------------------------------------------";
	s[p].replace((LENGTH - need) / 2, need, buffer);
	p++;

	//2.parameter section
	s[p++] = "|parameter------------------------------------------------|";

	CPI = (double)cycle / (cycle - ins);
	sprintf(buffer, "|cycle  %11d CPI    %11.8lf ", cycle, CPI);
	s[p] = buffer;

	switch (input)
	{
	case YO:
		s[p++] += "input     .yo file |"; break;
	case BIN:
		s[p++] += "input  binary file |"; break;
	case HEX:
		s[p++] += "input     hex file |"; break;
	}

	sprintf(buffer, "|speed  %11d ", speed);
	s[p] = buffer;
	if (save == SAV)
		s[p] += "save        enable ";
	else
		s[p] += "save       disable ";
	if (output == STI)
		s[p] += "output       still |";
	else
		s[p] += "output     rolling |";
	p++;

	//3.sequential update section
	s[p++] = "|sequential update----------------------------------------|";

	size = seq_do.size();
	if (size == 0)
	{
		i = 1;
		s[p++] = "|EMPTY                                                    |";
	}
	else
		for (i = 0; i < size; i++)
		{
			s[p] = "|" + seq_do[i];
			s[p].append(length - s[p].size(), ' ');
			s[p++] += "|";
		}

	for (; i < 4; i++)
		s[p++] = "|                                                         |";

	//4.register file section
	s[p++] = "|register file--------------------------------------------|";

	for (i = 0; i < 8; i += 2)
	{
		sprintf(buffer, "%11d ", reg[i]);
		s[p] = "|" + get_reg(i) + "   ";
		s[p] += buffer;

		sprintf(buffer, "%11d ", reg[i + 1]);
		s[p] += get_reg(i + 1) + "   ";
		s[p] += buffer;
		s[p].append(19, ' ');
		s[p++] += "|";
	}

	//5.CC section
	s[p++] = "|CC-------------------------------------------------------|";

	sprintf(buffer, "|ZF     %11d SF     %11d OF     %11d |", CC.ZF, CC.SF, CC.OF);
	s[p++] = buffer;

	//6.stat section
	s[p++] = "|Stat-----------------------------------------------------|";
	s[p++] = "|Stat          " + get_stat(Stat) + "                                       |";

	//7.W register section
	s[p++] = "|W register-----------------------------------------------|";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", W.bubble, W.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(W.stat);
	sprintf(buffer, " valE   %11d valM   %11d |", W.valE, W.valM);
	s[p++] += buffer;

	s[p] = "|icode  ";
	s[p].append(11 - get_icode(W.icode).size(), ' ');
	s[p] += get_icode(W.icode);
	s[p] += " dstE   ";
	s[p].append(11 - get_reg(W.dstE).size(), ' ');
	s[p] += get_reg(W.dstE);
	s[p] += " dstM   ";
	s[p].append(11 - get_reg(W.dstM).size(), ' ');
	s[p++] += get_reg(W.dstM) + " |";

	//8.M register section
	s[p++] = "|M register-----------------------------------------------|";

	if (m_do.size())
	{
		s[p] = "|" + m_do[0];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	else
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", M.bubble, M.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(M.stat);
	sprintf(buffer, " valE   %11d valA   %11d |", M.valE, M.valA);
	s[p++] += buffer;

	s[p] = "|icode  ";
	s[p].append(11 - get_icode(M.icode).size(), ' ');
	s[p] += get_icode(M.icode);
	s[p] += " dstE   ";
	s[p].append(11 - get_reg(M.dstE).size(), ' ');
	s[p] += get_reg(M.dstE);
	s[p] += " dstM   ";
	s[p].append(11 - get_reg(M.dstM).size(), ' ');
	s[p++] += get_reg(M.dstM) + " |";

	sprintf(buffer, "|Cnd    %11d                                       |", M.Cnd);
	s[p++] = buffer;

	//9.E register section
	s[p++] = "|E register-----------------------------------------------|";

	if (e_do.size())
	{
		s[p] = "|" + e_do[0];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	else
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", E.bubble, E.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(E.stat);
	temp = get_reg(E.dstE);
	s[p] += " dstE   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.dstM);
	s[p] += " dstM   ";
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	temp = get_icode(E.icode);
	s[p] = "|icode  ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	sprintf(buffer, " valA   %11d valB   %11d |", E.valA, E.valB);
	s[p++] += buffer;

	temp = get_ifun(E.icode, E.ifun);
	s[p] = "|ifun   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.srcA);
	s[p] += " srcA   ";
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	temp = get_reg(E.srcB);
	s[p] += " srcB   ";
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	sprintf(buffer, "|valC   %11d                                       |", E.valC);
	s[p++] = buffer;

	//10.D register section
	s[p++] = "|D register-----------------------------------------------|";

	size = d_do.size();
	for (i = 0; i < size; i++)
	{
		s[p] = "|" + d_do[i];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	for (; i < 2; i++)
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", D.bubble, D.stall);
	s[p++] = buffer;

	s[p] = "|stat          " + get_stat(D.stat);
	sprintf(buffer, " valC   %11d valP   ", D.valC);
	s[p] += buffer;
	s[p].append(13 - sprintf(buffer, "0x%x |", D.valP), ' ');
	s[p++] += buffer;

	s[p] = "|icode  ";
	temp = get_icode(D.icode);
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	s[p] += " rA     ";
	temp = get_reg(D.rA);
	s[p].append(11 - temp.size(), ' ');
	s[p] += temp;
	s[p] += " rB     ";
	temp = get_reg(D.rB);
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + " |";

	s[p] = "|ifun   ";
	temp = get_ifun(D.icode, D.ifun);
	s[p].append(11 - temp.size(), ' ');
	s[p++] += temp + "                                       |";

	//11.F register section
	s[p++] = "|F register-----------------------------------------------|";

	size = f_do.size();
	for (i = 0; i < size; i++)
	{
		s[p] = "|" + f_do[i];
		s[p].append(length - s[p].size(), ' ');
		s[p++] += "|";
	}
	for (; i < 5; i++)
		s[p++] = "|                                                         |";

	sprintf(buffer, "|bubble %11d stall  %11d                    |", F.bubble, F.stall);
	s[p++] = buffer;

	s[p] = "|f.pc   ";
	s[p].append(11 - sprintf(buffer, "0x%x", f.pc), ' ');
	s[p] += buffer;
	s[p] += " predPC ";
	s[p].append(11 - sprintf(buffer, "0x%x", F.predPC), ' ');
	s[p] += buffer;
	s[p++] += "                    |";

	//12.changed memory section
	s[p++] = "|changed memory-------------------------------------------|";

	if (changed.empty())
		s[p++] = "|EMPTY                                                    |";
	else
	{
		s[p++] = "|     address      |     decimal      |    hexadecimal    |";
		for (map<int, int>::const_iterator it = changed.begin(); it != changed.end(); it++)
		{
			s[p] = "|";
			s[p].append(18 - sprintf(buffer, "0x%x", it->first), ' ');
			s[p] += buffer;
			s[p] += "|";
			s[p].append(18 - sprintf(buffer, "%d", it->second), ' ');
			s[p] += buffer;
			s[p] += "|";
			s[p].append(18 - sprintf(buffer, "0x%x", it->second), ' ');
			s[p] += buffer;
			s[p++] += " |";
		}
	}

	//13.bottom line
	s[p++] = "-----------------------------------------------------------";

	//save as file?
	if (save == SAV)
	{
		for (i = 0; i < p; i++)
			fout << s[i] << endl;
		fout << endl << endl << endl;
	}

	//output
	if (output == STI)//double buffer display
	{
		COORD coord;//˫���崦����ʾ
		DWORD bytes;//����̨��Ļ���������
		HANDLE hOutput = CreateConsoleScreenBuffer(
			GENERIC_WRITE,//������̿�����������д����
			FILE_SHARE_WRITE,//���建�����ɹ���дȨ��
			NULL,
			CONSOLE_TEXTMODE_BUFFER,
			NULL
		);

		coord.X = 0;
		coord.Y = 0;
		bytes = 0;
		for (i = 0; i < p; i++)
		{
			coord.Y = i;
			WriteConsoleOutputCharacterA(hOutput, s[i].c_str(), s[i].size(), coord, &bytes);
		}
		SetConsoleActiveScreenBuffer(hOutput);
	}
	else//rolling display
	{
		for (i = 0; i < p; i++)
			cout << s[i] << endl;
		cout << endl << endl << endl;
	}
}