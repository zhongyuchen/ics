#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <Windows.h>
#include <fstream>

//icode(instruction code)
#define IHALT 0x0
#define INOP 0x1
#define IRRMOVL 0x2
#define IIRMOVL 0x3
#define IRMMOVL 0x4
#define IMRMOVL 0x5
#define IOPL 0x6
#define IJXX 0x7
#define ICALL 0x8
#define IRET 0x9
#define IPUSHL 0xa
#define IPOPL 0xb
#define IIADDL 0xc
#define ILEAVE 0xd

//ifun(instruction function code)
//1.icode default
#define FNONE 0x0
//2.icode IOPL
#define FADDL 0x0//ALU add operation
#define ALUADD 0x0//(for icode except IOPL) ALU add operation
#define FSUBL 0x1
#define FANDL 0x2
#define FXORL 0x3
//3.icode IJXX
#define FJMP 0x0
#define FJLE 0x1
#define FJL 0x2
#define FJE 0x3
#define FJNE 0x4
#define FJGE 0x5
#define FJG 0x6

//register function
#define EAX 0x0
#define ECX 0x1
#define EDX 0x2
#define EBX 0x3
#define ESP 0x4
#define EBP 0x5
#define ESI 0x6
#define EDI 0x7
#define E8 0x8
#define E9 0x9
#define E10 0xa
#define E11 0xb
#define E12 0xc
#define E13 0xd
#define E14 0xe
#define ENONE 0xf//not exist
//common register
#define RRSP 0x4//%esp
#define RNONE 0xf//no register

//instruction status values
#define SBUB 0x0//bubble
#define SAOK 0x1//normal
#define SADR 0x2//address abnormal
#define SINS 0x3//instruction abnormal
#define SHLT 0x4//halt

//memory size
#define MEMORY_SIZE 0x10000000

//output table size
#define OUTPUT_SIZE 300
#define LENGTH 59

//file category
#define YO 0
#define BIN 1
#define HEX 2

//display category
#define ROL 0
#define STI 1

//save file?
#define SAV 1
#define SEE 0

//colours
#define WHITE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE)
#define GREEN SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_GREEN)
#define BLUE SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_BLUE)
#define RED SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED)
#define YELLOW SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN)
#define MAGENTA SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_BLUE)
#define CYAN SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_GREEN | FOREGROUND_BLUE)

using namespace std;

struct F_register
{
	int predPC;
	bool bubble;
	bool stall;
};

struct f_value
{
	int icode;
	int ifun;
	int valC;
	int valP;
	int pc;
	int stat;
	int predPC;
	int rA;
	int rB;
};

struct need_value
{
	int valC;
	int regids;
};

struct instr_value
{
	bool valid;
};

struct imem_value
{
	int icode;
	int ifun;
	bool error;
};

struct D_register
{
	int stat;
	int icode;
	int ifun;
	int rA;
	int rB;
	int valC;
	int valP;
	bool bubble;
	bool stall;
};

struct d_value
{
	int srcA;
	int srcB;
	int dstE;
	int dstM;
	int valA;
	int valB;
	int rvalA;
	int rvalB;
	int stat;
	int icode;
	int ifun;
	int valC;
};

struct E_register
{
	int stat;
	int icode;
	int ifun;
	int valC;
	int valA;
	int valB;
	int dstE;
	int dstM;
	int srcA;
	int srcB;
	bool bubble;
	bool stall;
};

struct e_value
{
	int valE;
	int dstE;
	int dstM;
	int valA;
	int stat;
	int icode;
	bool Cnd;
};

struct alu_logic
{
	int A;
	int B;
	int fun;
	bool ZF;
	bool SF;
	bool OF;
};

struct CC_register
{
	bool ZF;//zero flag
	bool SF;//sign flag
	bool OF;//overflow flag
	bool set;
};

struct M_register
{
	int stat;
	int icode;
	int ifun;
	int Cnd;
	int valE;
	int valA;
	int dstE;
	int dstM;
	bool bubble;
	bool stall;
};

struct dmem_value
{
	bool error;
};

struct mem_value
{
	int addr;
	bool read;
	bool write;
};

struct m_value
{
	int valM;
	int stat;
	int icode;
	int valE;
	int dstE;
	int dstM;
};

struct W_register
{
	int stat;
	int icode;
	int valE;
	int valM;
	int dstE;
	int dstM;
	bool stall;
	bool bubble;
};

extern struct F_register F;
extern struct f_value f;
extern struct need_value need;
extern struct instr_value instr;
extern struct imem_value imem;
extern struct D_register D;
extern struct d_value d;
extern struct E_register E;
extern struct e_value e;
extern struct alu_logic alu;
extern struct CC_register CC;
extern struct M_register M;
extern struct dmem_value dmem;
extern struct mem_value mem;
extern struct m_value m;
extern struct W_register W;

extern int input;
extern int ins;
extern double CPI;
extern int speed;
extern int output;
extern int save;
extern int PC;
//clock cycle
extern int cycle;
extern bool error;//abnormal exit
				  //Stat: the actual state of the process
extern int Stat;

//memory
extern int memory[MEMORY_SIZE];
//register file
extern int reg[16];//eax, ecx, edx, ebx, esp, ebp, esi, edi, NULL

//move
extern vector<string> seq_do;
extern vector<string> m_do;
extern vector<string> e_do;
extern vector<string> d_do;
extern vector<string> f_do;
//changed memory
extern map<int, int> changed;

//file output
extern ofstream fout;

int char_to_int(char c);
string get_reg(int reg_fun);
string get_icode(int icode);
string get_ifun(int icode, int ifun);
string get_stat(int stat);

void simulator();

void hex_input();
void binary_input();
void yo_input();

void initialize();
void control_update();
void sequential_update();
void posedge_edge_clock();
void run();

void F_value_update();
void F_logic_update();
void F_stage();

void D_value_update();
void D_logic_update();
void D_stage();

void ALU();
void E_value_update();
void E_logic_update();
void E_stage();

bool check_segmentation(int pc);//input real address
void M_value_update();
void M_logic_update();
void M_stage();
int get_int(int address);

void W_value_update();
void W_logic_update();
void W_stage();
void write_int(int address, int value);

void table();